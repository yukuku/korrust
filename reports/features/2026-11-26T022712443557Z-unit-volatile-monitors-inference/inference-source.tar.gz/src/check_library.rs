pub(super) use super::relations::{specialize_receiver, type_owner};
use super::*;

pub(super) use crate::classpath::DEFAULT_KOTLIN_PACKAGES as DEFAULT_PACKAGES;

fn kotlin_default_bridge(
    classpath: &Classpath,
    owner: &str,
    method: &JavaMethod,
    seen: &mut HashSet<String>,
) -> Result<Option<JavaMethod>> {
    if !seen.insert(owner.into()) || seen.len() > 256 {
        return Ok(None);
    }
    let class = classpath.load(owner)?;
    let receiver = declarations::classifier_type(
        &class.name,
        class
            .library
            .as_ref()
            .map(|l| l.type_parameters.as_slice())
            .unwrap_or(&[]),
    );
    for parent in class.super_name.iter().chain(&class.interfaces) {
        let declaring = classpath.load(parent)?;
        if declaring.kotlin_interface {
            for candidate in declaring.methods.iter().filter(|candidate| {
                candidate.name == method.name
                    && candidate.access & 0x409 == 1
                    && !candidate.unsupported
            }) {
                let specialized =
                    specialize_receiver(candidate.clone(), &receiver, &declaring, classpath);
                if candidate.descriptor == method.descriptor
                    || declarations::logical_member_key(&specialized)?
                        == declarations::member_key(&method.name, &method.descriptor)
                {
                    return Ok(Some(candidate.clone()));
                }
            }
        }
        if let Some(candidate) = kotlin_default_bridge(classpath, parent, method, seen)? {
            return Ok(Some(candidate));
        }
    }
    Ok(None)
}

pub(super) fn ordinary_member_methods(
    classpath: &Classpath,
    owner: &str,
    name: &str,
    argument_count: usize,
) -> Result<Vec<JavaMethod>> {
    let mut methods = classpath
        .ordinary_methods(owner)?
        .into_iter()
        .map(|method| {
            if method.access & 0x40 != 0 && method.access & 9 == 1 {
                if method.unsupported
                    && classpath.load(owner)?.kotlin_class
                    && let Some(declaration) =
                        kotlin_default_bridge(classpath, owner, &method, &mut HashSet::new())?
                {
                    return Ok(declaration);
                }
                if let Some(declaration) = java_properties::accessibility_bridge(
                    classpath,
                    owner,
                    &method,
                    &mut HashSet::new(),
                )? {
                    return Ok(declaration);
                }
            }
            Ok(method)
        })
        .collect::<Result<Vec<_>>>()?;
    let mut seen = HashSet::new();
    methods.retain(|method| {
        seen.insert((
            method.owner.clone(),
            method.name.clone(),
            method.descriptor.clone(),
        ))
    });
    for mapping in crate::classpath::jvm_builtins::PROPERTY_MAPPINGS
        .iter()
        .filter(|mapping| mapping.jvm_name == name)
    {
        if relations::as_supertype(classpath, &Type::Java(owner.into()), mapping.owner).is_none() {
            continue;
        }
        for method in methods.iter_mut().filter(|method| {
            method.name == mapping.jvm_name
                && method.descriptor == mapping.descriptor
                && method.access & 9 == 1
        }) {
            method.source_property = Some(mapping.source_name.into());
        }
    }
    for mapping in crate::classpath::jvm_builtins::MAPPINGS
        .iter()
        .filter(|mapping| mapping.source_name == name)
    {
        if mapping.inherited_only && owner == mapping.owner {
            continue;
        }
        if relations::as_supertype(classpath, &Type::Java(owner.into()), mapping.owner).is_none() {
            continue;
        }
        let declarations =
            classpath.builtin_member_declarations(mapping.classifier, mapping.source_name)?;
        let declaration = declarations
            .iter()
            .find(|declaration| declaration.descriptor == mapping.descriptor)
            .ok_or_else(|| {
                Diagnostic::new(0, "Kotlin builtin JVM mapping does not match its metadata")
            })?;
        for method in methods.iter_mut().filter(|method| {
            !method.unsupported
                && method.name == mapping.jvm_name
                && method.descriptor == mapping.descriptor
                && method.access & 9 == 1
                && method.source_name() == method.name
        }) {
            method.kotlin_params = declaration.kotlin_params.clone();
            method.kotlin_result = declaration.kotlin_result.clone();
            method.library = declaration.library.clone();
            if let Some(library) = &mut method.library {
                library.abstract_ = method.access & 0x400 != 0;
            }
        }
    }
    let declarations = if methods.iter().any(|method| {
        method.owner == "java/lang/Object"
            && method.source_name() == name
            && method.access & 9 == 1
            && class_method_types(method)
                .is_ok_and(|(parameters, _)| parameters.len() == argument_count)
    }) {
        classpath.builtin_class_declarations("kotlin/Any")?
    } else {
        Vec::new()
    };
    Ok(methods
        .into_iter()
        .filter_map(|mut method| {
            if method.owner == "java/lang/Object" {
                let declaration = declarations.iter().find(|declaration| {
                    declaration.name == method.source_name()
                        && declaration.descriptor == method.descriptor
                })?;
                method.library = declaration.library.clone();
                method.kotlin_params = declaration.kotlin_params.clone();
                method.kotlin_result = declaration.kotlin_result.clone();
            }
            Some(method)
        })
        .collect())
}

pub(super) fn remove_overridden(
    methods: Vec<JavaMethod>,
    classpath: &Classpath,
) -> Vec<JavaMethod> {
    methods
        .iter()
        .filter(|method| {
            !methods.iter().any(|other| {
                other.owner != method.owner
                    && other.source_name() == method.source_name()
                    && other.instance_dispatch()
                    && method.instance_dispatch()
                    && relations::as_supertype(
                        classpath,
                        &Type::Java(other.owner.clone()),
                        &method.owner,
                    )
                    .is_some()
                    && class_method_types(other)
                        .ok()
                        .zip(class_method_types(method).ok())
                        .is_some_and(|((a, _), (b, _))| {
                            a.iter()
                                .map(Type::descriptor)
                                .eq(b.iter().map(Type::descriptor))
                        })
            })
        })
        .map(|method| {
            let mut method = method.clone();
            for parent in &methods {
                if parent.owner != method.owner
                    && parent.source_name() == method.source_name()
                    && relations::as_supertype(
                        classpath,
                        &Type::Java(method.owner.clone()),
                        &parent.owner,
                    )
                    .is_some()
                    && class_method_types(parent)
                        .ok()
                        .zip(class_method_types(&method).ok())
                        .is_some_and(|((a, _), (b, _))| {
                            a.iter()
                                .map(Type::descriptor)
                                .eq(b.iter().map(Type::descriptor))
                        })
                {
                    method.inherit_defaults(parent);
                }
            }
            method
        })
        .collect()
}

pub(super) fn default_argument_method(
    classpath: &Classpath,
    method: &JavaMethod,
) -> Result<JavaMethod> {
    let declaring = classpath.load(&method.owner)?;
    let Some(target) = declaring.methods.iter().find(|candidate| {
        candidate.name == method.name
            && candidate.descriptor == method.descriptor
            && candidate.access & 0x40 == 0
    }) else {
        return Ok(method.clone());
    };
    if target
        .kotlin_params
        .as_ref()
        .is_some_and(|params| params.iter().any(|p| p.2))
    {
        return Ok(target.clone());
    }
    let receiver = declarations::classifier_type(
        &declaring.name,
        declaring
            .library
            .as_ref()
            .map(|library| library.type_parameters.as_slice())
            .unwrap_or(&[]),
    );
    let (params, result) = class_method_types(target)?;
    let type_params = target
        .library
        .as_ref()
        .map(|library| library.type_parameters.as_slice())
        .unwrap_or(&[]);
    let mut pending = declaring.super_name.iter().cloned().collect::<Vec<_>>();
    let mut seen = HashSet::new();
    while let Some(owner) = pending.pop() {
        if !seen.insert(owner.clone()) {
            continue;
        }
        if seen.len() > 256 {
            return Err(Diagnostic::new(
                0,
                "Default argument inheritance exceeds the supported hierarchy depth",
            ));
        }
        let parent = classpath.load(&owner)?;
        for candidate in &parent.methods {
            if candidate.name != target.name
                || !candidate.instance_dispatch()
                || candidate.access & 0x42 != 0
                || !candidate
                    .kotlin_params
                    .as_ref()
                    .is_some_and(|params| params.iter().any(|p| p.2))
            {
                continue;
            }
            let specialized =
                specialize_receiver(candidate.clone(), &receiver, &declaring, classpath);
            if declarations::override_generic_signature(
                &specialized,
                &params,
                &result,
                type_params,
            )? {
                return Ok(candidate.clone());
            }
        }
        pending.extend(parent.super_name);
    }
    Err(Diagnostic::new(
        0,
        "Inherited default arguments require a supported matching class declaration",
    )
    .with_kind(
        crate::DiagnosticKind::UnsupportedLanguage,
        "INHERITED_DEFAULT_PROVIDER_UNSUPPORTED",
    ))
}

pub(super) fn static_import_owner(
    classpath: &Classpath,
    owner: &str,
    member: &str,
    offset: usize,
) -> Result<Option<JavaClass>> {
    let Ok(mut class) = classpath.load(owner) else {
        return Ok(None);
    };
    if class.access & 1 == 0 || class.unsupported {
        return Ok(None);
    }
    let methods = classpath.methods(owner)?;
    let matching_method = methods.iter().any(|method| {
        method.access & 9 == 9
            && (method.source_name() == member || method.source_property.as_deref() == Some(member))
            && (method.owner == owner
                || classpath
                    .load(&method.owner)
                    .is_ok_and(|declaring| declaring.access & 0x0200 == 0))
    });
    if class
        .fields
        .iter()
        .any(|field| field.name == "INSTANCE" && field.descriptor == format!("L{};", class.name))
        && methods.iter().any(|method| {
            method.access & 9 == 1
                && method
                    .library
                    .as_ref()
                    .is_some_and(|library| library.receiver.is_some())
                && (method.source_name() == member
                    || method.source_property.as_deref() == Some(member))
        })
    {
        return Err(Diagnostic::new(
            offset,
            "Explicit imports of singleton member extensions are unsupported",
        )
        .with_kind(
            crate::DiagnosticKind::UnsupportedLanguage,
            "SINGLETON_EXTENSION_IMPORT_UNSUPPORTED",
        ));
    }
    if class
        .library
        .as_ref()
        .and_then(|library| library.companion_name.as_deref())
        == Some("Companion")
        && class.fields.iter().any(|field| {
            field.name == member && field.kotlin.as_ref().is_some_and(|field| field.constant)
        })
    {
        return Err(Diagnostic::new(
            offset,
            "Companion constant imports require the companion qualifier",
        )
        .with_kind(
            crate::DiagnosticKind::InvalidKotlin,
            "CONST_IMPORT_QUALIFIER_INVALID",
        ));
    }
    let matching_field = classpath
        .field_candidates(owner, member)?
        .iter()
        .any(|field| field.access & 9 == 9);
    if !matching_method && !matching_field {
        return Ok(None);
    }
    if matching_method && class.access & 0x0200 != 0 {
        return Err(
            Diagnostic::new(offset, "Static interface method imports are unsupported").with_kind(
                crate::DiagnosticKind::UnsupportedLanguage,
                "STATIC_INTERFACE_IMPORT_UNSUPPORTED",
            ),
        );
    }
    class.methods = methods
        .into_iter()
        .filter(|method| {
            method.instance_dispatch()
                || method.owner == owner
                || classpath
                    .load(&method.owner)
                    .is_ok_and(|declaring| declaring.access & 0x0200 == 0)
        })
        .map(|mut method| {
            if method.access & 8 != 0
                && classpath
                    .load(&method.owner)
                    .is_ok_and(|declaring| !declaring.kotlin_class && declaring.access & 1 == 0)
            {
                method.owner = owner.into();
            }
            method
        })
        .collect();
    Ok(Some(class))
}

impl Checker<'_> {
    pub(super) fn lexical_method_visible(&self, method: &JavaMethod) -> bool {
        (!method.kotlin_internal || self.classpath.internal_visible(&method.owner))
            && (method.access & 1 != 0
                || method.access & 2 != 0
                    && (self.lambda_owner == method.owner
                        || self.lambda_owner.starts_with(&format!("{}$", method.owner)))
                || method.access & 4 != 0
                    && self.dispatch_receiver.as_ref().is_some_and(|receiver| {
                        self.subtype(&receiver.ty, &Type::Java(method.owner.clone()))
                    }))
    }

    pub(super) fn lexical_call(
        &mut self,
        name: &str,
        args: &[Expr],
        explicit: &[Type],
        expected: Option<&Type>,
        offset: usize,
    ) -> Result<Option<Value>> {
        let labeled = member_extensions::call_labels(name, args);
        let args = labeled.as_slice();
        if self.local(name).is_some() || self.captured.contains_key(name) {
            return Ok(None);
        }
        if let Some(value) = self.implicit_extension_receiver_call(name, args, explicit, offset)? {
            return Ok(Some(value));
        }
        let mut methods = self.object_methods.get(name).cloned().unwrap_or_default();
        methods.extend(
            self.members
                .values()
                .filter(|method| method.source_name() == name)
                .cloned(),
        );
        if let Some(owner) = self
            .dispatch_receiver
            .as_ref()
            .and_then(|receiver| type_owner(&receiver.ty))
        {
            if let Ok(inherited) = ordinary_member_methods(self.classpath, owner, name, args.len())
            {
                methods.extend(
                    inherited.into_iter().filter(|method| {
                        method.source_name() == name && method.instance_dispatch()
                    }),
                );
            }
        }
        methods.retain(|method| {
            method.source_property.is_none()
                && method
                    .library
                    .as_ref()
                    .is_none_or(|library| library.receiver.is_none())
                && self.lexical_method_visible(method)
        });
        let mut signatures = HashSet::new();
        methods
            .retain(|method| signatures.insert((method.name.clone(), method.descriptor.clone())));
        methods.sort_by(|a, b| {
            (&a.owner, &a.name, &a.descriptor).cmp(&(&b.owner, &b.name, &b.descriptor))
        });
        let mut applicable = Vec::new();
        for method in methods {
            let normalized = self.vararg_arguments(&method, args, offset)?;
            let (params, defaults) = Self::method_parameters(&method)?;
            if let Err(error) = Self::argument_mapping(
                &params,
                &defaults,
                &normalized,
                self.method_named(&method),
                offset,
            ) {
                if error.code == "ARGUMENT_MAPPING_MISMATCH" {
                    continue;
                }
                return Err(error);
            }
            match self.select_method_types(std::slice::from_ref(&method), args, explicit, offset) {
                Ok(_) => applicable.push(method),
                Err(error)
                    if error.code == "TYPE_MISMATCH"
                        && args.iter().any(|arg| {
                            let argument = if let ExprKind::NamedArgument(_, value)
                            | ExprKind::TrailingLambda(value) = &arg.kind
                            {
                                value.as_ref()
                            } else {
                                arg
                            };
                            error.offset == argument.offset
                        }) => {}
                Err(error) => return Err(error),
            }
        }
        if applicable.is_empty() {
            return Ok(None);
        }
        let method = self.select_method_types(&applicable, args, explicit, offset)?;
        let method = if expected.is_some() {
            let original = applicable
                .iter()
                .find(|original| {
                    original.owner == method.owner
                        && original.name == method.name
                        && original.descriptor == method.descriptor
                })
                .unwrap();
            self.select_method_expected(
                std::slice::from_ref(original),
                args,
                explicit,
                expected,
                offset,
            )?
        } else {
            method
        };
        let value = if !method.instance_dispatch() {
            self.library_static_call(method, args, offset)?
        } else {
            let receiver = self.dispatch_receiver_value(offset)?;
            self.member_call(method, receiver, args, offset)?
        };
        Ok(Some(value))
    }

    pub(super) fn inline_static_property_accessors(
        &self,
        name: &str,
        arity: usize,
    ) -> Result<Vec<JavaMethod>> {
        if !self.public_inline_body {
            return Ok(Vec::new());
        }
        let Some((owner, _)) = self.object_fields.get(name) else {
            return Ok(Vec::new());
        };
        Ok(self
            .classpath
            .methods(owner)?
            .into_iter()
            .filter(|method| {
                method.access & 8 != 0
                    && method.source_property.as_deref() == Some(name)
                    && method
                        .kotlin_params
                        .as_ref()
                        .is_some_and(|params| params.len() == arity)
            })
            .collect())
    }

    pub(super) fn library_candidates(&self, name: &str) -> Vec<JavaMethod> {
        self.library_candidates_with_members(name, true)
    }

    pub(super) fn library_call_candidates(&self, name: &str) -> Vec<JavaMethod> {
        self.library_candidates_with_members(name, false)
    }

    fn library_candidates_with_members(&self, name: &str, shadow_members: bool) -> Vec<JavaMethod> {
        if name == "this" && self.dispatch_receiver.is_some()
            || self.local(name).is_some()
            || self.captured.contains_key(name)
            || self.fields.contains_key(name)
            || self.object_fields.contains_key(name)
            || self.companion_fields.contains_key(name)
            || self.constants.contains_key(name)
            || shadow_members
                && self.object_methods.get(name).is_some_and(|methods| {
                    methods
                        .iter()
                        .any(|method| self.lexical_method_visible(method))
                })
            || shadow_members
                && self.members.values().any(|method| {
                    method.source_name() == name
                        && method.instance_dispatch()
                        && self.lexical_method_visible(method)
                })
            || shadow_members
                && self
                    .dispatch_receiver
                    .as_ref()
                    .and_then(|receiver| type_owner(&receiver.ty))
                    .is_some_and(|owner| {
                        self.classpath.methods(owner).is_ok_and(|methods| {
                            methods.iter().any(|method| {
                                method.source_name() == name
                                    && method.instance_dispatch()
                                    && self.lexical_method_visible(method)
                            })
                        })
                    })
        {
            return Vec::new();
        }
        let Some(binding) = self.imports.get(name) else {
            if shadow_members
                && self
                    .dispatch_receiver
                    .as_ref()
                    .and_then(|receiver| library::type_owner(&receiver.ty))
                    .is_some_and(|owner| {
                        self.classpath.methods(owner).is_ok_and(|methods| {
                            methods.iter().any(|method| {
                                method.source_name() == name
                                    && method.instance_dispatch()
                                    && self.lexical_method_visible(method)
                            })
                        })
                    })
            {
                return Vec::new();
            }
            if self.functions.contains_key(name)
                || shadow_members
                    && self.object_methods.get(name).is_some_and(|methods| {
                        methods
                            .iter()
                            .any(|method| self.lexical_method_visible(method))
                    })
                || shadow_members
                    && self.members.values().any(|method| {
                        (method.source_name() == name
                            || method.source_property.as_deref() == Some(name))
                            && self.lexical_method_visible(method)
                    })
            {
                return Vec::new();
            }
            let visible = |method: &JavaMethod| {
                method.access & 8 != 0
                    && (method.access & 1 != 0
                        || self
                            .classpath
                            .file_private_visible(&self.lambda_owner, method))
                    && (!method.kotlin_internal || self.classpath.internal_visible(&method.owner))
                    && (method.source_name() == name
                        || method.source_property.as_deref() == Some(name))
            };
            let package = self.lambda_owner.rsplit_once('/').map_or("", |(p, _)| p);
            let package_methods = self
                .classpath
                .package_methods(package, name)
                .unwrap_or_default();
            let mut methods = package_methods
                .into_iter()
                .filter(visible)
                .collect::<Vec<_>>();
            if methods.is_empty() {
                let mut declarations = HashSet::new();
                for (_, owner) in self
                    .imports
                    .iter()
                    .filter(|(key, _)| key.starts_with("*::"))
                {
                    if let Some(class) = self.classes.get(owner) {
                        let imported = if class
                            .library
                            .as_ref()
                            .is_some_and(|library| library.package.is_some())
                        {
                            None
                        } else {
                            self.classpath
                                .static_wildcard_owner(owner, 0)
                                .ok()
                                .flatten()
                        };
                        let class = imported.as_ref().unwrap_or(class);
                        let originals = self.classpath.methods(owner).unwrap_or_default();
                        for method in class.methods.iter().filter(|method| {
                            visible(method)
                                && !self.imports.iter().any(|(alias, binding)| {
                                    alias != name
                                        && !alias.starts_with("*::")
                                        && binding == &format!("{owner}::{name}")
                                })
                        }) {
                            let declaring = originals
                                .iter()
                                .find(|original| {
                                    original.name == method.name
                                        && original.descriptor == method.descriptor
                                })
                                .map_or(method.owner.as_str(), |original| original.owner.as_str());
                            if declarations.insert((
                                declaring.to_owned(),
                                method.name.clone(),
                                method.descriptor.clone(),
                            )) {
                                methods.push(method.clone());
                            }
                        }
                    }
                }
            }
            if !methods.is_empty() {
                methods.sort_by(|a, b| {
                    (&a.owner, &a.name, &a.descriptor).cmp(&(&b.owner, &b.name, &b.descriptor))
                });
                methods.dedup_by(|a, b| {
                    a.owner == b.owner && a.name == b.name && a.descriptor == b.descriptor
                });
                return methods;
            }
            if self.callable_name_was_renamed(name) {
                return Vec::new();
            }
            for package in DEFAULT_PACKAGES {
                if let Ok(package_methods) = self.classpath.package_methods(package, name) {
                    methods.extend(package_methods.into_iter().filter(|method| {
                        method.access & 8 != 0
                            && (method.access & 1 != 0
                                || self
                                    .classpath
                                    .file_private_visible(&self.lambda_owner, method)
                                || method
                                    .library
                                    .as_ref()
                                    .is_some_and(|library| library.inline && library.kotlin_public))
                            && (!method.kotlin_internal
                                || self.classpath.internal_visible(&method.owner))
                            && method.library.as_ref().is_some_and(|library| {
                                library.receiver.is_none() && library.source_name == name
                            })
                    }));
                }
            }
            methods.sort_by(|a, b| {
                (&a.owner, &a.name, &a.descriptor).cmp(&(&b.owner, &b.name, &b.descriptor))
            });
            methods.dedup_by(|a, b| {
                a.owner == b.owner && a.name == b.name && a.descriptor == b.descriptor
            });
            return methods;
        };
        let Some((owner, source_name)) = binding.rsplit_once("::") else {
            return Vec::new();
        };
        let package = self
            .classes
            .get(owner)
            .and_then(|c| c.library.as_ref())
            .and_then(|l| l.package.as_deref());
        self.classes
            .values()
            .filter(|c| {
                c.name == owner
                    || (c.library.as_ref().and_then(|l| l.package.as_deref()) == package
                        && package.is_some())
            })
            .flat_map(|c| &c.methods)
            .filter(|m| {
                m.access & 8 != 0
                    && (m.access & 1 != 0
                        || self.classpath.file_private_visible(&self.lambda_owner, m)
                        || m.library
                            .as_ref()
                            .is_some_and(|library| library.inline && library.kotlin_public))
                    && (m.source_property.as_deref() == Some(source_name)
                        || m.source_name() == source_name)
            })
            .cloned()
            .collect()
    }

    pub(super) fn library_static_call(
        &mut self,
        method: JavaMethod,
        args: &[Expr],
        offset: usize,
    ) -> Result<Value> {
        if method
            .library
            .as_ref()
            .is_some_and(|library| library.value_dispatch)
        {
            return Err(Diagnostic::new(
                offset,
                "Value class members require an instance receiver",
            )
            .with_kind(
                crate::DiagnosticKind::InvalidKotlin,
                "VALUE_MEMBER_RECEIVER_REQUIRED",
            ));
        }

        let method = self.classpath.source_value_method(method, false);
        if method
            .library
            .as_ref()
            .is_some_and(|library| library.suspend_ && library.inline)
        {
            return Err(
                Diagnostic::new(offset, "Compiled suspend inline calls are unsupported").with_kind(
                    crate::DiagnosticKind::UnsupportedLanguage,
                    "SUSPEND_INLINE_CALL_UNSUPPORTED",
                ),
            );
        }
        let labeled = member_extensions::call_labels(method.source_name(), args);
        let args = labeled.as_slice();
        let normalized = self.vararg_arguments(&method, args, offset)?;
        let args = normalized.as_slice();
        if self
            .classpath
            .load(&method.owner)
            .is_ok_and(|c| c.access & 0x0200 != 0)
        {
            return Err(Diagnostic::new(
                offset,
                "Static interface methods are unsupported",
            ));
        }
        let (types, result) = class_method_types(&method)?;
        let params = method
            .kotlin_params
            .as_ref()
            .map(|p| p.iter().map(|p| (p.0.clone(), p.1.clone())).collect())
            .unwrap_or_else(|| {
                types
                    .into_iter()
                    .enumerate()
                    .map(|(i, t)| (format!("p{i}"), java_parameter(t)))
                    .collect::<Vec<_>>()
            });
        let defaults = method
            .kotlin_params
            .as_ref()
            .map(|p| p.iter().map(|p| p.2).collect())
            .unwrap_or_else(|| vec![false; params.len()]);
        let named = self.method_named(&method);
        let inline_declaration = method
            .library
            .as_ref()
            .is_some_and(|m| m.inline && !m.builtin_array);
        let inline = inline_declaration && !self.inline_analysis;
        if inline_declaration {
            crate::compiled_inline::validate_access(&method, self.classpath, &self.lambda_owner)?;
        }
        let old_inline = self.inline_result.clone();
        self.inline_result = if inline && (self.allow_return || self.nonlocal_result.is_some()) {
            Some(
                self.nonlocal_result
                    .clone()
                    .unwrap_or_else(|| self.result.clone()),
            )
        } else {
            None
        };
        let old_modes = std::mem::replace(
            &mut self.inline_argument_modes,
            method
                .library
                .as_ref()
                .map(|library| library.parameter_modes.clone())
                .unwrap_or_default(),
        );
        let checked = self.arguments(&params, &defaults, args, named, offset);
        self.inline_result = old_inline;
        self.inline_argument_modes = old_modes;
        let (mut values, lets, mut mask) = checked?;
        let contract_facts = self.call_contract_facts(&method, &values, &lets);
        if method
            .library
            .as_ref()
            .is_some_and(|library| library.builtin_array)
        {
            if mask != 0 || values.len() != 1 {
                return Err(Diagnostic::new(
                    offset,
                    "Unsupported builtin array declaration shape",
                ));
            }
            let value = values.remove(0);
            return Ok(Self::wrap_lets(self.coerce(value, result, offset)?, lets));
        }
        if method.access & 1 == 0
            && !self
                .classpath
                .file_private_visible(&self.lambda_owner, &method)
            && method.owner != self.lambda_owner
            && (!inline_declaration
                || mask != 0
                || !method
                    .library
                    .as_ref()
                    .is_some_and(|library| library.kotlin_public))
        {
            return Err(Diagnostic::new(
                offset,
                "Private JVM inline declaration requires complete inline expansion",
            ));
        }
        if mask == 0
            && !self.public_inline_body
            && self.classpath.default_source_accessor(&method).is_some()
        {
            return Ok(Self::wrap_lets(
                self.source_backing_accessor(&method, values, offset)?
                    .unwrap(),
                lets,
            ));
        }
        if method
            .library
            .as_ref()
            .is_some_and(|l| l.receiver.is_some())
        {
            mask >>= 1;
        }
        let kind = if inline && mask == 0 {
            let code = method
                .library
                .as_ref()
                .and_then(|l| l.code.as_ref())
                .ok_or_else(|| Diagnostic::new(offset, "Compiled inline bytecode unavailable"))?;
            let local_base = self.next;
            self.next = self
                .next
                .checked_add(code.max_locals)
                .ok_or_else(|| Diagnostic::new(offset, "Inline locals overflow"))?;
            let mut lambda_bases = Vec::new();
            for (index, value) in values.iter().enumerate() {
                if method.library.as_ref().is_some_and(|library| {
                    library.parameter_modes.get(index)
                        == Some(&syntax::InlineParameterMode::Noinline)
                }) {
                    lambda_bases.push(None);
                    continue;
                }
                let owner = match &value.kind {
                    ValueKind::Lambda { owner, .. } => Some(owner),
                    ValueKind::Local(slot) => {
                        lets.iter()
                            .find_map(|(saved, initializer)| match &initializer.kind {
                                ValueKind::Lambda { owner, .. } if saved == slot => Some(owner),
                                _ => None,
                            })
                    }
                    _ => None,
                };
                if let Some(owner) = owner {
                    let lambdas = self.lambdas.borrow();
                    let lambda = lambdas.iter().find(|l| l.owner == *owner).ok_or_else(|| {
                        Diagnostic::new(offset, "Inline lambda declaration missing")
                    })?;
                    lambda_bases.push(Some((owner.clone(), self.next)));
                    self.next = self
                        .next
                        .checked_add(lambda.function.locals)
                        .ok_or_else(|| Diagnostic::new(offset, "Inline lambda locals overflow"))?;
                } else {
                    lambda_bases.push(None);
                }
            }
            if self.next > 256 {
                return Err(Diagnostic::new(
                    offset,
                    "Compiled inline locals exceed current limit",
                ));
            }
            let reified_temp = if method
                .library
                .as_ref()
                .is_some_and(|library| !library.reified_arguments.is_empty())
            {
                if self.next >= 256 {
                    return Err(Diagnostic::new(
                        offset,
                        "Reified inline locals exceed the current JVM slot limit",
                    )
                    .with_kind(
                        crate::DiagnosticKind::UnsupportedLanguage,
                        "COMPILED_INLINE_LOCALS_UNSUPPORTED",
                    ));
                }
                let slot = self.next;
                self.next += 1;
                Some(slot)
            } else {
                None
            };
            ValueKind::CompiledInline {
                method,
                args: values,
                local_base,
                lambda_bases,
                reified_temp,
            }
        } else if mask == 0 {
            ValueKind::JavaCall {
                method,
                args: values,
            }
        } else {
            if inline {
                return Err(Diagnostic::new(
                    offset,
                    "Compiled inline default arguments are unsupported",
                ));
            }
            let split = method.descriptor.find(')').unwrap();
            let descriptor = format!(
                "({}{}Ljava/lang/Object;){}",
                &method.descriptor[1..split],
                "I".repeat(
                    (params.len()
                        - usize::from(
                            method
                                .library
                                .as_ref()
                                .is_some_and(|library| library.receiver.is_some())
                        ))
                    .div_ceil(32)
                ),
                &method.descriptor[split + 1..]
            );
            for index in 0..(params.len()
                - usize::from(
                    method
                        .library
                        .as_ref()
                        .is_some_and(|library| library.receiver.is_some()),
                ))
            .div_ceil(32)
            {
                values.push(Value {
                    ty: Type::Int,
                    kind: ValueKind::Int((mask >> (index * 32)) as i32),
                });
            }
            values.push(Value {
                ty: Type::Java("java/lang/Object".into()),
                kind: ValueKind::Null,
            });
            ValueKind::StaticCall {
                owner: method.owner,
                name: format!("{}$default", method.name),
                descriptor,
                args: values,
            }
        };
        self.contract_registration = Some(offset);
        self.contract_facts.insert(offset, contract_facts);
        Ok(Self::wrap_lets(Value { ty: result, kind }, lets))
    }

    pub(super) fn extension_call(
        &mut self,
        receiver: Value,
        name: &str,
        args: &[Expr],
        types: &[Type],
        offset: usize,
    ) -> Result<Value> {
        self.resolved_extension_call(
            receiver,
            name,
            args,
            types,
            operations::ExtensionKind::Ordinary,
            offset,
        )
    }
}

impl Checker<'_> {
    pub(super) fn source_call(
        &mut self,
        name: &str,
        args: &[Expr],
        explicit: &[Type],
        offset: usize,
    ) -> Result<Value> {
        if let Ok(class) = self.classpath.load(&self.lambda_owner) {
            let inline = class
                .methods
                .iter()
                .filter(|method| {
                    method.source_name() == name
                        && method
                            .library
                            .as_ref()
                            .is_some_and(|library| library.inline && library.code.is_some())
                })
                .cloned()
                .collect::<Vec<_>>();
            if !inline.is_empty() {
                let method = self.select_method_types(&inline, args, explicit, offset)?;
                return self.library_static_call(method, args, offset);
            }
            if !self.inline_analysis
                && class.methods.iter().any(|method| {
                    method.source_name() == name
                        && method
                            .library
                            .as_ref()
                            .is_some_and(|library| library.inline)
                })
            {
                return Err(Diagnostic::new(
                    offset,
                    "Source inline dependency was not staged; unsupported call dependency",
                )
                .with_kind(
                    crate::DiagnosticKind::UnsupportedLanguage,
                    "SOURCE_INLINE_DEPENDENCY_UNSUPPORTED",
                ));
            }
        }
        if let Ok(class) = self.classpath.load(&self.lambda_owner) {
            let methods = class
                .methods
                .into_iter()
                .filter(|method| method.source_name() == name)
                .collect::<Vec<_>>();
            if methods.iter().any(|method| method.access & 0x80 != 0)
                || !self
                    .function_names
                    .iter()
                    .any(|candidate| candidate == name)
                    && !methods.is_empty()
            {
                let method = self.select_method_types(&methods, args, explicit, offset)?;
                return self.library_static_call(method, args, offset);
            }
        }
        let mut candidates = self
            .function_names
            .iter()
            .enumerate()
            .filter(|(_, n)| *n == name)
            .map(|(i, _)| i)
            .collect::<Vec<_>>();
        if candidates.is_empty() {
            if let Some(id) = self.functions.get(name) {
                candidates.push(*id);
            }
        }
        let id = if explicit.is_empty() {
            self.select_function(&candidates, args, offset)?
        } else {
            self.select_function_types(&candidates, args, explicit, offset)?
        };
        if self.extensions.contains(&id) {
            return Err(Diagnostic::new(
                offset,
                "Calling declared Kotlin extensions is not supported",
            ));
        }
        let (params, result) = self.specialize_source(id, args, explicit, offset)?;
        let defaults = self
            .defaults
            .get(id)
            .map(|v| v.iter().map(Option::is_some).collect::<Vec<_>>())
            .unwrap_or_else(|| vec![false; params.len()]);
        let (values, lets, mask) = self.arguments(&params, &defaults, args, true, offset)?;
        Ok(Self::wrap_lets(
            Value {
                ty: result,
                kind: if mask == 0 {
                    ValueKind::Call(id, values)
                } else {
                    ValueKind::DefaultCall(id, values, mask as u32)
                },
            },
            lets,
        ))
    }
}

pub(super) fn default_class(classpath: &Classpath, name: &str) -> Option<JavaClass> {
    if name.contains('/') || name.contains('.') || name.contains('$') {
        return None;
    }
    std::iter::once("java/lang")
        .chain(DEFAULT_PACKAGES.iter().copied())
        .find_map(|package| {
            classpath
                .load(&format!("{package}/{name}"))
                .ok()
                .filter(|class| class.access & 1 != 0)
        })
}

pub(super) fn default_type_imports(
    ty: &Type,
    imports: &HashMap<String, String>,
    classpath: &Classpath,
) -> HashMap<String, String> {
    fn visit(ty: &Type, imports: &mut HashMap<String, String>, classpath: &Classpath) {
        match ty {
            Type::Java(name) => {
                if !imports.contains_key(name) {
                    if let Some(class) =
                        default_class(classpath, name).or_else(|| classpath.kotlin_classifier(name))
                    {
                        imports.insert(name.clone(), class.name);
                    }
                }
            }
            Type::Parameterized { name, arguments } => {
                visit(&Type::Java(name.clone()), imports, classpath);
                for arg in arguments {
                    if let Some(ty) = &arg.ty {
                        visit(ty, imports, classpath);
                    }
                }
            }
            Type::Array(inner)
            | Type::Nullable(inner)
            | Type::Platform(inner)
            | Type::List(inner)
            | Type::MutableList(inner)
            | Type::ThreadLocal(inner) => visit(inner, imports, classpath),
            Type::Parameter { upper_bound, .. } => visit(upper_bound, imports, classpath),
            Type::Function { params, result } | Type::SuspendFunction { params, result } => {
                for param in params {
                    visit(param, imports, classpath);
                }
                visit(result, imports, classpath);
            }
            Type::ReceiverFunction {
                receiver,
                params,
                result,
            } => {
                visit(receiver, imports, classpath);
                for param in params {
                    visit(param, imports, classpath);
                }
                visit(result, imports, classpath);
            }
            _ => (),
        }
    }
    let mut resolved = imports.clone();
    visit(ty, &mut resolved, classpath);
    resolved
}

impl Checker<'_> {
    pub(super) fn default_constructor(
        &mut self,
        name: &str,
        args: &[Expr],
        offset: usize,
    ) -> Result<Option<Value>> {
        if self.functions.contains_key(name)
            || self.local(name).is_some()
            || self.captured.contains_key(name)
            || self.object_methods.contains_key(name)
            || self.fields.contains_key(name)
            || self.object_fields.contains_key(name)
            || self.companion_fields.contains_key(name)
            || self.constants.contains_key(name)
            || self.members.values().any(|method| {
                method.source_name() == name || method.source_property.as_deref() == Some(name)
            })
        {
            return Ok(None);
        }
        let requested = Type::Java(name.into());
        let expanded = self
            .classpath
            .expand_type_alias(&requested, self.imports, DEFAULT_PACKAGES)
            .map_err(|error| {
                if error.code == "TYPE_ALIAS_ARITY" {
                    Diagnostic::new(
                        offset,
                        "Generic alias construction requires explicit type arguments",
                    )
                    .with_kind(
                        crate::DiagnosticKind::UnsupportedLanguage,
                        "GENERIC_CONSTRUCTOR_INFERENCE_UNSUPPORTED",
                    )
                } else {
                    error
                }
            })?;
        let alias = expanded != requested;
        let mut expanded = expanded;
        while let Type::Nullable(inner) = expanded {
            expanded = *inner;
        }
        if alias && matches!(expanded, Type::Parameterized { .. }) {
            return self.generic_constructor(name, &[], args, offset);
        }
        if !alias && self.imports.contains_key(name) {
            return Ok(None);
        }
        let source_package = self
            .lambda_owner
            .rsplit_once('/')
            .map_or("", |(package, _)| package);
        let source_name = if source_package.is_empty() {
            name.into()
        } else {
            format!("{source_package}/{name}")
        };
        let class = if alias {
            let ty = self.resolve(&expanded, offset)?;
            let owner = library::type_owner(&ty).ok_or_else(|| {
                Diagnostic::new(offset, "Type alias does not name a constructible class").with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "TYPE_ALIAS_CONSTRUCTOR_INVALID",
                )
            })?;
            Some(self.classpath.load(owner)?)
        } else if let Some(crate::classpath::ValueSymbol::Classifier(class)) = self
            .classpath
            .value_symbol(&self.lambda_owner, name, offset)?
        {
            Some(*class)
        } else {
            self.classpath
                .load(&source_name)
                .ok()
                .filter(|class| class.access & 1 != 0)
                .or_else(|| default_class(self.classpath, name))
        };
        let Some(class) = class else {
            return Ok(None);
        };
        self.classpath
            .check_classifier_visibility(&self.lambda_owner, &class.name, offset)?;
        if class.access & 0x2000 != 0 {
            return Err(Diagnostic::new(
                offset,
                "Runtime annotation instance construction is unsupported",
            )
            .with_kind(
                crate::DiagnosticKind::UnsupportedLanguage,
                "ANNOTATION_INSTANCE_CONSTRUCTION_UNSUPPORTED",
            ));
        }
        if class.access & 1 == 0 {
            return Err(
                Diagnostic::new(offset, "Constructor classifier is inaccessible").with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "INACCESSIBLE_CONSTRUCTOR",
                ),
            );
        }
        if class.access & (0x200 | 0x400) != 0 {
            return Err(Diagnostic::new(
                offset,
                "Abstract classes and interfaces cannot be constructed",
            )
            .with_kind(
                crate::DiagnosticKind::InvalidKotlin,
                "ABSTRACT_CONSTRUCTION_INVALID",
            ));
        }
        let mapped = crate::classpath::kotlin_mapped_classifier(&class.name);
        let builtin = !class.kotlin_class
            && mapped.is_some_and(|classifier| {
                alias && expanded == Type::String
                    || !alias && classifier.rsplit('/').next() == Some(name)
            });
        let contract = if builtin {
            Some(self.classpath.builtin_constructors(mapped.unwrap())?)
        } else {
            None
        };
        let constructors = class
            .methods
            .iter()
            .filter(|method| {
                method.name == "<init>"
                    && self
                        .classpath
                        .constructor_visible(&self.lambda_owner, method)
                    && !method.unsupported
            })
            .filter_map(|method| {
                let mut method = method.clone();
                if let Some(contract) = &contract {
                    let declaration = contract
                        .iter()
                        .find(|declaration| declaration.descriptor == method.descriptor)?;
                    method.kotlin_params = declaration.kotlin_params.clone();
                    method.kotlin_result = declaration.kotlin_result.clone();
                }
                Some(method)
            })
            .collect::<Vec<_>>();
        if let Some(contract) = &contract {
            if contract.is_empty() {
                return Err(Diagnostic::new(
                    offset,
                    "No accessible constructor in the Kotlin builtin contract",
                )
                .with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "BUILTIN_CONSTRUCTOR_NOT_ACCESSIBLE",
                ));
            }
            if constructors.is_empty() {
                return Err(Diagnostic::new(
                    offset,
                    "Kotlin builtin constructor has no matching JVM declaration",
                )
                .with_kind(
                    crate::DiagnosticKind::UnsupportedLanguage,
                    "BUILTIN_CONSTRUCTOR_JVM_MISMATCH",
                ));
            }
        }
        if constructors.is_empty()
            && class.methods.iter().any(|m| {
                m.name == "<init>" && !self.classpath.constructor_visible(&self.lambda_owner, m)
            })
        {
            return Err(
                Diagnostic::new(offset, "Constructor is inaccessible").with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "INACCESSIBLE_CONSTRUCTOR",
                ),
            );
        }
        let method = self.select_method(&constructors, args, offset)?;
        let normalized = self.vararg_arguments(&method, args, offset)?;
        let (params, defaults) = Self::method_parameters(&method)?;
        self.constructor_call(
            &class.name,
            &params,
            &defaults,
            &normalized,
            self.method_named(&method),
            offset,
        )
        .map(Some)
    }
}

impl Checker<'_> {
    pub(super) fn generic_constructor(
        &mut self,
        name: &str,
        types: &[Type],
        args: &[Expr],
        offset: usize,
    ) -> Result<Option<Value>> {
        if self
            .imports
            .get(name)
            .is_some_and(|binding| binding.contains("::"))
        {
            return Ok(None);
        }
        let requested = Type::Parameterized {
            name: name.into(),
            arguments: types
                .iter()
                .map(|ty| {
                    Ok(syntax::TypeArgument {
                        variance: syntax::Variance::Invariant,
                        ty: Some(self.resolve(ty, offset)?),
                    })
                })
                .collect::<Result<Vec<_>>>()?,
        };
        let mut expanded =
            self.classpath
                .expand_type_alias(&requested, self.imports, DEFAULT_PACKAGES)?;
        let alias = expanded != requested;
        while let Type::Nullable(inner) = expanded {
            expanded = *inner;
        }
        let class = if alias {
            let owner = library::type_owner(&expanded).ok_or_else(|| {
                Diagnostic::new(offset, "Type alias does not name a constructible class").with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "TYPE_ALIAS_CONSTRUCTOR_INVALID",
                )
            })?;
            self.classes
                .get(owner)
                .cloned()
                .map(Ok)
                .unwrap_or_else(|| self.classpath.load(owner))?
        } else if let Some(owner) = self.imports.get(name) {
            self.classes
                .get(owner)
                .cloned()
                .map(Ok)
                .unwrap_or_else(|| self.classpath.load(owner))?
        } else if let Some(class) = default_class(self.classpath, name) {
            class
        } else {
            return Ok(None);
        };
        self.classpath
            .check_classifier_visibility(&self.lambda_owner, &class.name, offset)?;
        if class.access & 1 == 0 {
            return Err(
                Diagnostic::new(offset, "Constructor classifier is inaccessible").with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "INACCESSIBLE_CONSTRUCTOR",
                ),
            );
        }
        let ty = if alias {
            self.resolve(&expanded, offset)?
        } else {
            let Type::Parameterized { arguments, .. } = requested else {
                unreachable!()
            };
            Type::Parameterized {
                name: class.name.clone(),
                arguments,
            }
        };
        let Some(library) = &class.library else {
            return Err(Diagnostic::new(
                offset,
                "Class has no supported type parameters",
            ));
        };
        let Type::Parameterized { arguments, .. } = &ty else {
            return Err(Diagnostic::new(
                offset,
                "Generic constructor requires a parameterized class",
            ));
        };
        if library.type_parameters.len() != arguments.len() {
            return Err(Diagnostic::new(
                offset,
                "Wrong number of constructor type arguments",
            ));
        }
        relations::validate_type_arguments_with_classes(&ty, self.classpath, self.classes, offset)?;
        self.classpath
            .check_classifier_visibility(&self.lambda_owner, &class.name, offset)?;
        if class.access & 0x2000 != 0 {
            return Err(Diagnostic::new(
                offset,
                "Runtime annotation instance construction is unsupported",
            )
            .with_kind(
                crate::DiagnosticKind::UnsupportedLanguage,
                "ANNOTATION_INSTANCE_CONSTRUCTION_UNSUPPORTED",
            ));
        }
        if class.access & (0x200 | 0x400) != 0 {
            return Err(Diagnostic::new(
                offset,
                "Abstract classes and interfaces cannot be constructed",
            )
            .with_kind(
                crate::DiagnosticKind::InvalidKotlin,
                "ABSTRACT_CONSTRUCTION_INVALID",
            ));
        }
        let constructors = class
            .methods
            .iter()
            .filter(|method| {
                method.name == "<init>"
                    && self
                        .classpath
                        .constructor_visible(&self.lambda_owner, method)
                    && !method.unsupported
            })
            .cloned()
            .map(|method| library::specialize_receiver(method, &ty, &class, self.classpath))
            .collect::<Vec<_>>();
        if constructors.is_empty()
            && class.methods.iter().any(|m| {
                m.name == "<init>" && !self.classpath.constructor_visible(&self.lambda_owner, m)
            })
        {
            return Err(
                Diagnostic::new(offset, "Constructor is inaccessible").with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "INACCESSIBLE_CONSTRUCTOR",
                ),
            );
        }
        let method = self.select_method(&constructors, args, offset)?;
        let normalized = self.vararg_arguments(&method, args, offset)?;
        let args = normalized.as_slice();
        let (params, defaults) = Self::method_parameters(&method)?;
        let (values, lets, mask) =
            self.arguments(&params, &defaults, args, self.method_named(&method), offset)?;
        let mut raw = method.clone();
        raw.kotlin_params = None;
        raw.kotlin_result = None;
        let (storage, _) = class_method_types(&raw)?;
        let mut values = values
            .into_iter()
            .zip(storage)
            .map(|(value, ty)| self.coerce(value, java_parameter(ty), offset))
            .collect::<Result<Vec<_>>>()?;
        let descriptor = if mask == 0 {
            method.descriptor.clone()
        } else {
            for index in 0..params.len().div_ceil(32) {
                values.push(Value {
                    ty: Type::Int,
                    kind: ValueKind::Int((mask >> (index * 32)) as i32),
                });
            }
            values.push(Value {
                ty: Type::Java("kotlin/jvm/internal/DefaultConstructorMarker".into()),
                kind: ValueKind::Null,
            });
            format!(
                "{}{}Lkotlin/jvm/internal/DefaultConstructorMarker;)V",
                method.descriptor.trim_end_matches(")V"),
                "I".repeat(params.len().div_ceil(32))
            )
        };
        Ok(Some(Self::wrap_lets(
            Value {
                ty,
                kind: ValueKind::New {
                    owner: class.name,
                    descriptor,
                    args: values,
                },
            },
            lets,
        )))
    }
}

impl Checker<'_> {
    pub(super) fn qualified_java_classifier(
        &self,
        expression: &Expr,
        offset: usize,
    ) -> Result<Option<(JavaClass, Option<u16>)>> {
        fn parts<'a>(expression: &'a Expr, names: &mut Vec<&'a str>) -> bool {
            match &expression.kind {
                ExprKind::Name(name) => {
                    names.push(name);
                    true
                }
                ExprKind::Property(receiver, name) if parts(receiver, names) => {
                    names.push(name);
                    true
                }
                _ => false,
            }
        }
        let mut names = Vec::new();
        if !parts(expression, &mut names) || names.len() < 2 || self.value_name_is_bound(names[0]) {
            return Ok(None);
        }
        let symbol = self
            .classpath
            .value_symbol(&self.lambda_owner, names[0], offset)?;
        let (mut class, mut cursor) = match symbol {
            Some(crate::classpath::ValueSymbol::Classifier(class)) if !class.kotlin_class => {
                (*class, 1)
            }
            Some(_) => return Ok(None),
            None => {
                if !self.unshadowed(names[0]) {
                    return Ok(None);
                }
                let found = (1..=names.len()).rev().find_map(|end| {
                    self.classpath
                        .load(&names[..end].join("/"))
                        .ok()
                        .filter(|class| {
                            class.access & 1 != 0 && !class.kotlin_class && !class.unsupported
                        })
                        .map(|class| (class, end))
                });
                let Some(found) = found else {
                    return Ok(None);
                };
                found
            }
        };
        let mut access = None;
        while cursor < names.len() {
            let Some((nested, flags)) = self
                .classpath
                .java_member_class(&class.name, names[cursor])?
            else {
                return Ok(None);
            };
            let caller_package = self
                .lambda_owner
                .rsplit_once('/')
                .map_or("", |(package, _)| package);
            let owner_package = class
                .name
                .rsplit_once('/')
                .map_or("", |(package, _)| package);
            if flags & 2 != 0
                || flags & 7 == 0 && caller_package != owner_package
                || nested.access & 1 == 0 && caller_package != owner_package
            {
                return Err(
                    Diagnostic::new(offset, "Nested Java classifier is inaccessible")
                        .with_kind(crate::DiagnosticKind::InvalidKotlin, "INVISIBLE_REFERENCE"),
                );
            }
            if flags & 4 != 0 || nested.unsupported {
                return Err(Diagnostic::new(
                    offset,
                    "Protected or unsupported nested Java classifier metadata",
                )
                .with_kind(
                    crate::DiagnosticKind::UnsupportedLanguage,
                    "JAVA_NESTED_CLASS_UNSUPPORTED",
                ));
            }
            class = nested;
            access = Some(flags);
            cursor += 1;
        }
        Ok(Some((class, access)))
    }

    pub(super) fn qualified_classifier(&self, expression: &Expr) -> Result<Option<JavaClass>> {
        fn parts(expression: &Expr, names: &mut Vec<String>) -> bool {
            match &expression.kind {
                ExprKind::Name(name) => {
                    names.push(name.clone());
                    true
                }
                ExprKind::Property(receiver, name) if parts(receiver, names) => {
                    names.push(name.clone());
                    true
                }
                _ => false,
            }
        }
        let mut names = Vec::new();
        if !parts(expression, &mut names) || names.len() < 2 {
            return Ok(None);
        }
        let root = &names[0];
        if self.local(root).is_some()
            || self.captured.contains_key(root)
            || self.constants.contains_key(root)
            || self.fields.contains_key(root)
            || self.object_fields.contains_key(root)
            || self.companion_fields.contains_key(root)
            || self
                .members
                .values()
                .any(|method| method.source_property.as_ref() == Some(root))
        {
            return Ok(None);
        }
        let qualified = names.join("/");
        let owner = self
            .imports
            .get(&qualified)
            .cloned()
            .or_else(|| {
                self.imports
                    .get(&names[0])
                    .map(|root| format!("{root}${}", names[1..].join("$")))
            })
            .unwrap_or(qualified);
        let class = self
            .classpath
            .load(&owner)
            .ok()
            .or_else(|| self.classpath.kotlin_classifier(&owner));
        if let Some(class) = &class {
            self.classpath.check_classifier_visibility(
                &self.lambda_owner,
                &class.name,
                expression.offset,
            )?;
        }
        Ok(class.filter(|class| class.access & 1 != 0 && !class.unsupported))
    }
    fn java_callee_collision(
        &mut self,
        expression: &Expr,
        args: &[Expr],
        offset: usize,
    ) -> Result<Option<Value>> {
        let ExprKind::Property(receiver, name) = &expression.kind else {
            return Ok(None);
        };
        let parent = self.value_classifier(receiver)?.or(self
            .qualified_java_classifier(receiver, offset)?
            .map(|(class, _)| class));
        let Some(parent) = parent.filter(|class| !class.kotlin_class) else {
            return Ok(None);
        };
        let Some((nested, flags)) = self.classpath.java_member_class(&parent.name, name)? else {
            return Ok(None);
        };
        let methods = self
            .classpath
            .methods(&parent.name)?
            .into_iter()
            .filter(|method| {
                method.source_name() == name
                    && method.access & 8 != 0
                    && (method.owner == parent.name
                        || self
                            .classpath
                            .load(&method.owner)
                            .is_ok_and(|class| class.access & 0x200 == 0))
            })
            .collect::<Vec<_>>();
        if methods.is_empty() {
            return Ok(None);
        }
        let package = |owner: &str| {
            owner
                .rsplit_once('/')
                .map_or("", |(package, _)| package)
                .to_owned()
        };
        let same_package = package(&self.lambda_owner) == package(&nested.name);
        let arity_may_match = |method: &JavaMethod| {
            method.access & 0x80 != 0
                || class_method_types(method)
                    .is_ok_and(|(parameters, _)| parameters.len() == args.len())
        };
        let unhandled_method = methods.iter().any(|method| {
            arity_may_match(method)
                && (method.unsupported
                    || method.access & 3 == 0
                        && (package(&self.lambda_owner) == package(&method.owner)
                            || method.access & 4 != 0))
        });
        if unhandled_method {
            return Err(Diagnostic::new(
                offset,
                "Java callee collision has unsupported candidate visibility or metadata",
            )
            .with_kind(
                crate::DiagnosticKind::UnsupportedLanguage,
                "JAVA_CALLEE_CANDIDATE_UNSUPPORTED",
            ));
        }
        let class_visible = flags & 2 == 0
            && (flags & 7 != 0 || same_package)
            && (nested.access & 1 != 0 || same_package);
        let constructors = nested
            .methods
            .iter()
            .filter(|method| method.name == "<init>")
            .cloned()
            .collect::<Vec<_>>();
        let unhandled_constructor = class_visible
            && flags & 8 != 0
            && (nested.unsupported
                || flags & 4 != 0
                || nested.access & 0x2000 != 0
                || nested
                    .library
                    .as_ref()
                    .is_some_and(|library| !library.type_parameters.is_empty())
                || constructors
                    .iter()
                    .any(|method| method.access & 3 == 0 && same_package || method.unsupported))
            && constructors.iter().any(arity_may_match);
        if unhandled_constructor {
            return Err(Diagnostic::new(
                offset,
                "Java callee collision has unsupported constructor visibility or metadata",
            )
            .with_kind(
                crate::DiagnosticKind::UnsupportedLanguage,
                "JAVA_CALLEE_CANDIDATE_UNSUPPORTED",
            ));
        }
        let mut candidates = methods
            .into_iter()
            .filter(|method| method.access & 1 != 0 && !method.unsupported)
            .collect::<Vec<_>>();
        if class_visible && flags & 8 != 0 {
            candidates.extend(
                constructors
                    .into_iter()
                    .filter(|method| method.access & 1 != 0 && !method.unsupported),
            );
        }
        if candidates.is_empty() {
            return Ok(None);
        }
        let mut method = self
            .select_method(&candidates, args, offset)
            .map_err(|error| {
                if error.message.contains("Ambiguous") {
                    error.with_kind(
                        crate::DiagnosticKind::InvalidKotlin,
                        "AMBIGUOUS_JAVA_CALLEE",
                    )
                } else {
                    error
                }
            })?;
        if method.name == "<init>" {
            return Ok(None);
        }
        if self
            .classpath
            .load(&method.owner)
            .is_ok_and(|class| !class.kotlin_class && class.access & 1 == 0)
        {
            method.owner = parent.name;
        }
        self.library_static_call(method, args, offset).map(Some)
    }

    pub(super) fn qualified_constructor(
        &mut self,
        expression: &Expr,
        args: &[Expr],
        offset: usize,
    ) -> Result<Option<Value>> {
        if let Some(value) = self.java_callee_collision(expression, args, offset)? {
            return Ok(Some(value));
        }
        let java = self.qualified_java_classifier(expression, offset)?;
        if java
            .as_ref()
            .is_some_and(|(_, access)| access.is_some_and(|access| access & 8 == 0))
        {
            return Err(Diagnostic::new(
                offset,
                "Inner constructor requires an enclosing instance",
            )
            .with_kind(
                crate::DiagnosticKind::InvalidKotlin,
                "INNER_CONSTRUCTOR_RECEIVER_REQUIRED",
            ));
        }
        let class = if let Some((class, _)) = java {
            Some(class)
        } else {
            self.qualified_classifier(expression)?
                .filter(|class| class.kotlin_class)
        };
        let Some(class) = class else {
            return Ok(None);
        };
        if class
            .fields
            .iter()
            .any(|f| f.name == "INSTANCE" && f.descriptor == format!("L{};", class.name))
        {
            return Ok(None);
        }
        self.classpath
            .check_classifier_visibility(&self.lambda_owner, &class.name, offset)?;
        if class.access & 0x2000 != 0 {
            return Err(Diagnostic::new(
                offset,
                "Runtime annotation instance construction is unsupported",
            )
            .with_kind(
                crate::DiagnosticKind::UnsupportedLanguage,
                "ANNOTATION_INSTANCE_CONSTRUCTION_UNSUPPORTED",
            ));
        }
        if class.access & (0x200 | 0x400) != 0 {
            return Err(Diagnostic::new(
                offset,
                "Abstract classes and interfaces cannot be constructed",
            )
            .with_kind(
                crate::DiagnosticKind::InvalidKotlin,
                "ABSTRACT_CONSTRUCTION_INVALID",
            ));
        }
        if class
            .library
            .as_ref()
            .is_some_and(|l| !l.type_parameters.is_empty())
        {
            return Err(Diagnostic::new(
                offset,
                "Qualified generic construction requires unsupported explicit classifier handling",
            )
            .with_kind(
                crate::DiagnosticKind::UnsupportedLanguage,
                "QUALIFIED_GENERIC_CONSTRUCTOR_UNSUPPORTED",
            ));
        }
        let constructors = class
            .methods
            .iter()
            .filter(|m| {
                m.name == "<init>"
                    && self.classpath.constructor_visible(&self.lambda_owner, m)
                    && !m.unsupported
            })
            .cloned()
            .collect::<Vec<_>>();
        if constructors.is_empty() && !class.kotlin_class {
            let private = class
                .methods
                .iter()
                .filter(|method| method.name == "<init>")
                .all(|method| method.access & 2 != 0);
            return Err(Diagnostic::new(
                offset,
                "Qualified Java constructor is inaccessible or requires unsupported visibility",
            )
            .with_kind(
                if private {
                    crate::DiagnosticKind::InvalidKotlin
                } else {
                    crate::DiagnosticKind::UnsupportedLanguage
                },
                if private {
                    "INVISIBLE_REFERENCE"
                } else {
                    "JAVA_CONSTRUCTOR_VISIBILITY_UNSUPPORTED"
                },
            ));
        }
        if constructors.is_empty()
            && class.methods.iter().any(|m| {
                m.name == "<init>" && !self.classpath.constructor_visible(&self.lambda_owner, m)
            })
        {
            return Err(
                Diagnostic::new(offset, "Constructor is inaccessible").with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "INACCESSIBLE_CONSTRUCTOR",
                ),
            );
        }
        let method = self.select_method(&constructors, args, offset)?;
        let normalized = self.vararg_arguments(&method, args, offset)?;
        let (params, defaults) = Self::method_parameters(&method)?;
        self.constructor_call(
            &class.name,
            &params,
            &defaults,
            &normalized,
            self.method_named(&method),
            offset,
        )
        .map(Some)
    }
}

impl Checker<'_> {
    fn value_name_is_bound(&self, name: &str) -> bool {
        name == "this"
            || self.local(name).is_some()
            || self.captured.contains_key(name)
            || self.constants.contains_key(name)
            || self.fields.contains_key(name)
            || self.object_fields.contains_key(name)
            || self.companion_fields.contains_key(name)
            || self
                .members
                .values()
                .any(|method| method.source_property.as_deref() == Some(name))
            || self
                .dispatch_receiver
                .as_ref()
                .and_then(|receiver| type_owner(&receiver.ty))
                .is_some_and(|owner| {
                    self.classpath.methods(owner).is_ok_and(|methods| {
                        methods.iter().any(|method| {
                            method.source_property.as_deref() == Some(name)
                                && self.lexical_method_visible(method)
                        })
                    })
                })
    }

    pub(super) fn value_classifier(&self, expression: &Expr) -> Result<Option<JavaClass>> {
        let ExprKind::Name(name) = &expression.kind else {
            return Ok(None);
        };
        if self.value_name_is_bound(name) {
            return Ok(None);
        }
        Ok(
            match self
                .classpath
                .value_symbol(&self.lambda_owner, name, expression.offset)?
            {
                Some(crate::classpath::ValueSymbol::Classifier(class)) => Some(*class),
                _ => None,
            },
        )
    }

    pub(super) fn imported_value(&mut self, name: &str, offset: usize) -> Result<Option<Value>> {
        if self.value_name_is_bound(name) {
            return Ok(None);
        }
        match self
            .classpath
            .value_symbol(&self.lambda_owner, name, offset)?
        {
            Some(crate::classpath::ValueSymbol::Field(field)) => self
                .java_field(&field.owner, &field.name, None, offset)
                .map(Some),
            Some(crate::classpath::ValueSymbol::Property(methods)) => {
                let method = self.select_method(&methods, &[], offset)?;
                self.library_static_call(method, &[], offset).map(Some)
            }
            Some(crate::classpath::ValueSymbol::Classifier(class)) => {
                if let Some(companion) = self.companion_receiver(&class.name, offset)? {
                    return Ok(Some(companion));
                }
                if class.fields.iter().any(|field| {
                    field.name == "INSTANCE" && field.descriptor == format!("L{};", class.name)
                }) {
                    return Ok(Some(Value {
                        ty: Type::Java(class.name.clone()),
                        kind: ValueKind::ObjectInstance(class.name),
                    }));
                }
                Ok(None)
            }
            _ => Ok(None),
        }
    }
}
