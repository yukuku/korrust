@qualifiers.GlobalWarning
package globalwarning;
