package valuecontext
@JvmInline value class V(val raw: Int)
class ContextHost { companion object { fun body(): Int { val value = V(11); return value.raw } } }
