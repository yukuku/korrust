from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,hashlib,shutil,subprocess,time,os
r=Path('/Users/yuku/f/git/korrust');d=r/'target/resume-value-context-probes';handoff=json.loads((r/'target/resume-values/handoff.json').read_text());original_report=r/handoff['report'];value_report=json.loads(original_report.read_text());original_binary=Path(value_report['compiler']['path']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(original_binary)==handoff['compiler_sha256']==value_report['compiler']['sha256'];compiler=d/'korrust-value-v3';shutil.copy2(original_binary,compiler)
home=Path('/Users/yuku/Library/Java/JavaVirtualMachines/jbr-21.0.8/Contents/Home');java=home/'bin/java';javac=home/'bin/javac';javap=home/'bin/javap';kotlinc=r/'references/kotlinc/bin/kotlinc';stdlib=r/'references/kotlinc/lib/kotlin-stdlib.jar'
base='package valuecontext\n@JvmInline value class V(val raw: Int)\n'
cases=[
 ('object_body','object ContextObject { fun body(): Int { val value = V(7); return value.raw } }','valuecontext.ContextObject.INSTANCE.body()',7,'valuecontext.ContextObject'),
 ('companion_body','class ContextHost { companion object { fun body(): Int { val value = V(11); return value.raw } } }','valuecontext.ContextHost.Companion.body()',11,'valuecontext.ContextHost$Companion'),
 ('enum_method','enum class ContextEnum { A; fun body(): Int { val value = V(13); return value.raw } }','valuecontext.ContextEnum.A.body()',13,'valuecontext.ContextEnum'),
 ('enum_entry_initializer','enum class ContextEnum(val code: Int) { A(V(17).raw) }','valuecontext.ContextEnum.A.getCode()',17,'valuecontext.ContextEnum'),
 ('interface_default_body','interface ContextInterface { fun body(): Int { val value = V(19); return value.raw } }\nclass ContextImpl : ContextInterface','new valuecontext.ContextImpl().body()',19,'valuecontext.ContextInterface'),
 ('enum_value_parameter','enum class ContextEnum(val value: V) { A(V(23)); fun body(): Int = value.raw }','valuecontext.ContextEnum.A.body()',23,'valuecontext.ContextEnum'),
]
commands=[];results=[]
def run(label,argv):
 start=time.monotonic();p=subprocess.run(list(map(str,argv)),cwd=r,capture_output=True,text=True,timeout=120);entry={'label':label,'argv':list(map(str,argv)),'cwd':str(r),'exit_code':p.returncode,'wall_time_seconds':time.monotonic()-start}
 for stream in ['stdout','stderr']:
  file=d/f'{len(commands):03d}-{stream}.txt';file.write_text(getattr(p,stream));entry[stream]=str(file.relative_to(r))
 commands.append(entry);return p
identity=run('pinned-official-identity',[kotlinc,'-version']);assert 'kotlinc-jvm 2.3.21 ' in identity.stdout+identity.stderr
for name,source,call,expected,owner in cases:
 work=d/name;work.mkdir();kotlin=work/'Context.kt';kotlin.write_text(base+source+'\n');driver=work/'Check.java';driver.write_text('public final class Check { public static void main(String[] args) { int actual = '+call+'; if (actual != '+str(expected)+') throw new AssertionError("expected '+str(expected)+' but was " + actual); } }\n')
 result={'id':name,'source':str(kotlin.relative_to(r)),'source_sha256':sha(kotlin),'java_caller_source_sha256':sha(driver),'expected_result':expected};outputs={provider:work/provider for provider in ['official','candidate']}
 official=run(name+'/official-compile',[kotlinc,kotlin,'-language-version','2.3','-api-version','2.3','-jvm-target','1.8','-module-name','value_context_'+name,'-cp',stdlib,'-d',outputs['official']]);result['official_compile_exit']=official.returncode
 candidate=run(name+'/candidate-compile',[compiler,kotlin,'--module-name','value_context_'+name,'--diagnostic-format','json','-cp',stdlib,'-d',outputs['candidate']]);result['candidate_compile_exit']=candidate.returncode;result['candidate_diagnostics']=[json.loads(line) for line in candidate.stderr.splitlines() if line.startswith('{')];result['candidate_explicit_unsupported']=candidate.returncode!=0 and any(item.get('category')=='unsupported_language' for item in result['candidate_diagnostics']);result['candidate_stderr']=candidate.stderr
 for provider in ['official','candidate']:
  result[provider+'_classes_sha256']={str(p.relative_to(work)):sha(p) for p in sorted(outputs[provider].rglob('*.class'))}
 if official.returncode==0:
  callers=work/'callers';compiled=run(name+'/fixed-java-compile',[javac,'-cp',str(outputs['official'])+os.pathsep+str(stdlib),'-d',callers,driver]);result['fixed_java_compile_exit']=compiled.returncode
  if compiled.returncode==0:
   caller_hash=sha(callers/'Check.class');result['fixed_java_caller_sha256']=caller_hash
   for provider in ['official','candidate']:
    if provider=='candidate' and candidate.returncode!=0:continue
    execution=run(name+'/'+provider+'-verified-runtime',[java,'-Xverify:all','-cp',os.pathsep.join(map(str,[callers,outputs[provider],stdlib])),'Check']);result[provider+'_runtime_exit']=execution.returncode;result[provider+'_runtime_stderr']=execution.stderr
    run(name+'/'+provider+'-javap',[javap,'-p','-c','-s','-classpath',outputs[provider],owner])
   result['fixed_java_caller_unchanged']=sha(callers/'Check.class')==caller_hash
 if official.returncode!=0:result['outcome']='oracle_failure'
 elif candidate.returncode!=0:result['outcome']='explicit_unsupported' if result['candidate_explicit_unsupported'] else 'candidate_rejection'
 elif result.get('candidate_runtime_exit')==0:result['outcome']='pass'
 else:result['outcome']='runtime_failure'
 results.append(result);report={'schema_version':1,'kind':'correctness','created_at':datetime.now(timezone.utc).isoformat(),'status':'running' if len(results)!=len(cases) else 'completed','selection':'Small independent value-class body/emitter context probes; fixed official Java callers reused against both outputs under -Xverify:all. No root source changes.','compiler':{'path':str(compiler.relative_to(r)),'sha256':sha(compiler),'handoff':str((r/'target/resume-values/handoff.json').relative_to(r)),'handoff_report':str(original_report.relative_to(r)),'handoff_report_sha256':sha(original_report)},'reference_compiler':{'version':'2.3.21','stdlib_sha256':sha(stdlib)},'commands':commands,'cases':results,'counts':dict(Counter(item['outcome'] for item in results))};(d/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({key:result.get(key) for key in ['id','outcome','official_compile_exit','candidate_compile_exit','candidate_explicit_unsupported','official_runtime_exit','candidate_runtime_exit','candidate_runtime_stderr','candidate_stderr']},indent=2),flush=True)
