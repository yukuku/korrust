package valuecontext
@JvmInline value class V(val raw: Int)
enum class ContextEnum { A; fun body(): Int { val value = V(13); return value.raw } }
