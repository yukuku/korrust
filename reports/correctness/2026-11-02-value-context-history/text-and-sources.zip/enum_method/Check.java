public final class Check { public static void main(String[] args) { int actual = valuecontext.ContextEnum.A.body(); if (actual != 13) throw new AssertionError("expected 13 but was " + actual); } }
