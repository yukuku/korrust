package valuecontext
@JvmInline value class V(val raw: Int)
fun read(value: V): Int = value.raw
interface ContextInterface { fun body(): Int { val value = V(19); return read(value) } }
class ContextImpl : ContextInterface
