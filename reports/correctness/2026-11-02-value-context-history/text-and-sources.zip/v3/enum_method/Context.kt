package valuecontext
@JvmInline value class V(val raw: Int)
fun read(value: V): Int = value.raw
enum class ContextEnum { A; fun body(): Int { val value = V(13); return read(value) } }
