package valuecontext
@JvmInline value class V(val raw: Int)
fun read(value: V): Int = value.raw
class ContextHost { companion object { fun body(): Int { val value = V(11); return read(value) } } }
