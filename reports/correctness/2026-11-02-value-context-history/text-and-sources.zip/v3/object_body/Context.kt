package valuecontext
@JvmInline value class V(val raw: Int)
fun read(value: V): Int = value.raw
object ContextObject { fun body(): Int { val value = V(7); return read(value) } }
