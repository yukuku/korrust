from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,time
from collections import Counter
r=Path('/Users/yuku/f/git/korrust');d=r/'target/resume-value-context-probes/fixed';d.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();compiler=d/'korrust';shutil.copy2(r/'target/resume-root-build/release/korrust',compiler)
home=Path('/Users/yuku/Library/Java/JavaVirtualMachines/jbr-21.0.8/Contents/Home');stdlib=r/'references/kotlinc/lib/kotlin-stdlib.jar';env={**os.environ,'JAVA_HOME':str(home)};commands=[];results=[]
def run(label,argv):
 p=subprocess.run(list(map(str,argv)),cwd=r,env=env,capture_output=True,text=True,timeout=120);n=len(commands);entry={'label':label,'argv':list(map(str,argv)),'exit_code':p.returncode}
 for stream in ['stdout','stderr']:
  path=d/f'{n:03d}-{stream}.txt';path.write_text(getattr(p,stream));entry[stream]=str(path.relative_to(r))
 commands.append(entry);return p
for version in ['v2','v3']:
 previous=json.loads((r/f'target/resume-value-context-probes/{version}/report.json').read_text())
 for item in previous['cases']:
  name=version+'/'+item['id'];directory=d/(version+'-'+item['id']);directory.mkdir();source=r/item['source'];assert sha(source)==item['source_sha256'];old=source.parent;out=directory/'candidate';p=run(name+'/compile',[compiler,source,'--module-name','value_context_'+item['id'],'--diagnostic-format','json','-cp',stdlib,'-d',out]);diagnostics=[json.loads(line) for line in p.stderr.splitlines() if line.startswith('{')];result={'id':name,'source':str(source.relative_to(r)),'source_sha256':sha(source),'candidate_compile_exit':p.returncode,'diagnostics':diagnostics}
  if version=='v2' and item['id']!='enum_value_parameter':
   assert p.returncode==0,(name,p.stderr);callers=old/'callers';assert sha(callers/'Check.class')==item['fixed_java_caller_sha256'];runtime=run(name+'/runtime',[home/'bin/java','-Xverify:all','-cp',os.pathsep.join(map(str,[callers,out,stdlib])),'Check']);assert runtime.returncode==0,(name,runtime.stderr);assert sha(callers/'Check.class')==item['fixed_java_caller_sha256'];result.update(outcome='pass',fixed_java_caller_sha256=item['fixed_java_caller_sha256'],runtime_exit=runtime.returncode)
  else:
   assert p.returncode!=0 and any(x.get('category')=='unsupported_language' for x in diagnostics),(name,p.stderr);result['outcome']='explicit_unsupported'
  results.append(result);print(name,result['outcome'],flush=True)
tree=ast.parse((r/'tools/check_value_classes.py').read_text());boundaries=next(ast.literal_eval(n.value) for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='boundaries' for x in n.targets))
for name,valid,text,code in boundaries:
 if 'physical' not in name:continue
 directory=d/name;directory.mkdir();source=directory/'Boundary.kt';source.write_text(text+'\n');oracle=run(name+'/oracle',[r/'references/kotlinc/bin/kotlinc',source,'-cp',stdlib,'-language-version','2.3','-api-version','2.3','-jvm-target','1.8','-d',directory/'official']);p=run(name+'/candidate',[compiler,source,'--diagnostic-format','json','-cp',stdlib,'-d',directory/'candidate']);diagnostics=[json.loads(line) for line in p.stderr.splitlines() if line.startswith('{')];assert oracle.returncode==0,(name,oracle.stderr);assert p.returncode!=0 and any(x.get('category')=='unsupported_language' and x.get('code')==code for x in diagnostics),(name,p.stderr);results.append({'id':name,'outcome':'explicit_unsupported','source_sha256':sha(source),'official_compile_exit':oracle.returncode,'candidate_compile_exit':p.returncode,'diagnostics':diagnostics});print(name,'explicit_unsupported',flush=True)
report={'compiler':{'path':str(compiler.relative_to(r)),'sha256':sha(compiler)},'cases':results,'counts':dict(Counter(x['outcome'] for x in results)),'commands':commands,'status':'complete','prior_positive_report':'target/resume-value-context-probes/v2/report.json','prior_failure_report':'target/resume-value-context-probes/v3/report.json','source_hashes':{name:sha(r/name) for name in ['src/lib.rs','tools/check_value_classes.py']}};(d/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(report['counts'],flush=True)
