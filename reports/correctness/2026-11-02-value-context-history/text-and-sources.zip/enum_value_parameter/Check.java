public final class Check { public static void main(String[] args) { int actual = valuecontext.ContextEnum.A.body(); if (actual != 23) throw new AssertionError("expected 23 but was " + actual); } }
