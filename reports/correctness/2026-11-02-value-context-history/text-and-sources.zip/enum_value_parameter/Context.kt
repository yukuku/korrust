package valuecontext
@JvmInline value class V(val raw: Int)
enum class ContextEnum(val value: V) { A(V(23)); fun body(): Int = value.raw }
