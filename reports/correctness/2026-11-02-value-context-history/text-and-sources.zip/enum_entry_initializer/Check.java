public final class Check { public static void main(String[] args) { int actual = valuecontext.ContextEnum.A.getCode(); if (actual != 17) throw new AssertionError("expected 17 but was " + actual); } }
