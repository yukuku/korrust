package valuecontext
@JvmInline value class V(val raw: Int)
enum class ContextEnum(val code: Int) { A(V(17).raw) }
