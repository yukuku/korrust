package valuecontext
@JvmInline value class V(val raw: Int)
object ContextObject { fun body(): Int { val value = V(7); return value.raw } }
