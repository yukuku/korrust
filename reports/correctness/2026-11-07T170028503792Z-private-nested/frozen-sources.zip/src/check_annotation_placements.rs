use super::*;
use crate::bytecode::annotation_files::{ClassAnnotations, MemberAnnotations};

pub(super) fn preflight_property_visibility(
    module: &syntax::Module,
    classpath: &Classpath,
) -> Result<()> {
    let imports = module
        .imports
        .iter()
        .map(|(name, owner, _)| (name.clone(), owner.clone()))
        .collect::<HashMap<_, _>>();
    macro_rules! validate {
        ($properties:expr) => {
            for property in $properties {
                property_visibility_annotations(
                    &property.annotations,
                    property.visibility(),
                    property.setter_visibility(),
                    !property.body.is_empty(),
                    property.setter.is_some(),
                    property.internal
                        || property.getter_visibility.is_some()
                        || property.setter_visibility.is_some(),
                    classpath,
                    &imports,
                )?;
            }
        };
    }
    validate!(&module.properties);
    if let Some(class) = &module.class_decl {
        validate!(&class.properties);
        if let Some(companion) = &class.companion {
            validate!(&companion.properties);
        }
    }
    if let Some(object) = &module.object_decl {
        validate!(&object.fields);
    }
    if let Some(interface) = &module.interface_decl {
        if let Some(companion) = &interface.companion {
            validate!(&companion.fields);
        }
    }
    Ok(())
}

pub(crate) fn preflight_file_annotation_semantics(
    module: &syntax::Module,
    classpath: &Classpath,
    scope: Option<&str>,
) -> Result<()> {
    if module.file_annotations.is_empty() {
        return Ok(());
    }
    let imports = crate::annotation_declarations::imports(module, classpath)?;
    for annotation in &module.file_annotations {
        let canonical = annotations::annotation_owner(&annotation.name, classpath, &imports);
        let canonical = if canonical == annotation.name
            && !canonical.contains('/')
            && classpath.load(&canonical).is_err()
        {
            match canonical.as_str() {
                "OptIn" | "RequiresOptIn" | "Suppress" | "MustUseReturnValues" => {
                    format!("kotlin/{canonical}")
                }
                "JvmName" | "JvmMultifileClass" => format!("kotlin/jvm/{canonical}"),
                _ => canonical,
            }
        } else {
            canonical
        };
        if matches!(
            canonical.as_str(),
            "kotlin/OptIn"
                | "kotlin/RequiresOptIn"
                | "kotlin/Suppress"
                | "kotlin/MustUseReturnValues"
                | "kotlin/internal/JvmBuiltin"
                | "kotlin/internal/SuppressBytecodeGeneration"
        ) {
            if classpath
                .load(&canonical)
                .is_ok_and(|class| class.annotation_definition.is_some())
            {
                annotations::declaration_annotations(
                    std::slice::from_ref(annotation),
                    classpath,
                    &imports,
                    "FILE",
                    Some("file"),
                    scope,
                )?;
            }
            return Err(Diagnostic::new(
                annotation.offset,
                "File annotation requires unsupported Kotlin compiler semantics",
            )
            .with_kind(
                crate::DiagnosticKind::UnsupportedLanguage,
                "FILE_ANNOTATION_SEMANTICS_UNSUPPORTED",
            ));
        }
        if let Some(code) = annotations::unsupported_lowering(&canonical) {
            return Err(Diagnostic::new(
                annotation.offset,
                "File annotation requires unsupported compiler lowering",
            )
            .with_kind(crate::DiagnosticKind::UnsupportedLanguage, code));
        }
    }
    Ok(())
}

pub(crate) fn file_annotations(
    module: &syntax::Module,
    classpath: &Classpath,
    scope: Option<&str>,
) -> Result<Vec<DeclarationAnnotation>> {
    preflight_file_annotation_semantics(module, classpath, scope)?;
    if module.file_annotations.is_empty() {
        return Ok(Vec::new());
    }
    let imports = crate::annotation_declarations::imports(module, classpath)?;
    annotations::declaration_annotations(
        &module.file_annotations,
        classpath,
        &imports,
        "FILE",
        Some("file"),
        scope,
    )
}

pub(crate) fn annotation_placements(
    module: &syntax::Module,
    classpath: &Classpath,
    owner: &str,
) -> Result<std::collections::BTreeMap<String, ClassAnnotations>> {
    let mut imports = crate::annotation_declarations::imports(module, classpath)?;
    let mut result = std::collections::BTreeMap::new();
    let mut output = ClassAnnotations {
        annotations: file_annotations(module, classpath, Some(owner))?,
        ..ClassAnnotations::default()
    };
    if let Some(class) = &module.class_decl {
        imports.insert(class.name.clone(), owner.into());
        output.annotations = checked(owner, &class.annotations, classpath, &imports, "TYPE", None)?;
        constructor_parameters(owner, class, false, classpath, &imports, &mut output)?;
        for property in &class.properties {
            property_visibility_annotations(
                &property.annotations,
                property.visibility(),
                property.setter_visibility(),
                !property.body.is_empty(),
                property.setter.is_some(),
                property.internal
                    || property.getter_visibility.is_some()
                    || property.setter_visibility.is_some(),
                classpath,
                &imports,
            )?;
            property_annotations(
                owner,
                &property.annotations,
                &property.name,
                &property.ty,
                property.mutable,
                property.private,
                property.initializer.is_some()
                    || property.lateinit
                    || property.body.is_empty() && property.delegate.is_none(),
                classpath,
                &imports,
                &mut output,
            )?;
        }
        for function in &class.methods {
            function_parameters(&function.function, classpath, &imports, owner, &mut output)?;
        }
        if let Some(companion) = &class.companion {
            let companion_owner = format!("{owner}$Companion");
            let mut companion_output = ClassAnnotations::default();
            for method in &companion.methods {
                function_parameters(
                    &method.function,
                    classpath,
                    &imports,
                    &companion_owner,
                    &mut companion_output,
                )?;
                if checked(
                    owner,
                    &method.function.annotations,
                    classpath,
                    &imports,
                    "METHOD",
                    None,
                )?
                .iter()
                .any(|annotation| annotation.descriptor == "Lkotlin/jvm/JvmStatic;")
                {
                    function_parameters(&method.function, classpath, &imports, owner, &mut output)?;
                }
            }
            for property in &companion.properties {
                property_visibility_annotations(
                    &property.annotations,
                    property.visibility(),
                    property.setter_visibility(),
                    !property.body.is_empty(),
                    property.setter.is_some(),
                    property.internal
                        || property.getter_visibility.is_some()
                        || property.setter_visibility.is_some(),
                    classpath,
                    &imports,
                )?;
                if !property.annotations.is_empty() {
                    return Err(Diagnostic::new(
                        property.offset,
                        "Annotations on companion properties require unsupported split backing-field placement",
                    ).with_kind(crate::DiagnosticKind::UnsupportedLanguage, "ANNOTATION_COMPANION_PROPERTY_UNSUPPORTED"));
                }
            }
            result.insert(companion_owner, companion_output);
        }
    } else if let Some(object) = &module.object_decl {
        imports.insert(object.name.clone(), owner.into());
        // The established empty serializable-singleton lowering already emits
        // its consumed marker and serializer API. Preserve that bounded path;
        // general plugin annotations remain rejected by ordinary validation.
        let empty_singleton = object.fields.is_empty()
            && object.methods.is_empty()
            && object.constants.is_empty()
            && object.objects.is_empty()
            && object.nested.is_empty();
        let ordinary = object
            .annotation_uses
            .iter()
            .filter(|annotation| {
                !(empty_singleton
                    && annotation.arguments.is_empty()
                    && annotation.use_site.is_none()
                    && imports
                        .get(&annotation.name)
                        .map(String::as_str)
                        .unwrap_or(&annotation.name)
                        == "kotlinx/serialization/Serializable")
            })
            .cloned()
            .collect::<Vec<_>>();
        output.annotations = checked(owner, &ordinary, classpath, &imports, "TYPE", None)?;
        for property in &object.fields {
            property_visibility_annotations(
                &property.annotations,
                property.visibility(),
                property.setter_visibility(),
                !property.body.is_empty(),
                property.setter.is_some(),
                property.internal
                    || property.getter_visibility.is_some()
                    || property.setter_visibility.is_some(),
                classpath,
                &imports,
            )?;
            if let Some(ty) = &property.ty {
                property_annotations(
                    owner,
                    &property.annotations,
                    &property.name,
                    ty,
                    property.mutable,
                    property.private,
                    true,
                    classpath,
                    &imports,
                    &mut output,
                )?;
            } else if !property.annotations.is_empty() {
                return Err(Diagnostic::new(
                    property.offset,
                    "Cannot place annotations on unresolved property",
                )
                .with_kind(
                    crate::DiagnosticKind::UnsupportedLanguage,
                    "ANNOTATION_PROPERTY_TYPE_UNSUPPORTED",
                ));
            }
        }
        for method in &object.methods {
            function_parameters(&method.function, classpath, &imports, owner, &mut output)?;
        }
    } else if let Some(interface) = &module.interface_decl {
        imports.insert(interface.name.clone(), owner.into());
        output.annotations = checked(
            owner,
            &interface.annotations,
            classpath,
            &imports,
            "TYPE",
            None,
        )?;
        for property in &interface.properties {
            if !property.annotations.is_empty() {
                return Err(Diagnostic::new(
                    property.offset,
                    "Annotations on interface properties are not supported",
                )
                .with_kind(
                    crate::DiagnosticKind::UnsupportedLanguage,
                    "ANNOTATION_INTERFACE_PROPERTY_UNSUPPORTED",
                ));
            }
        }
        for method in &interface.methods {
            function_parameters(&method.function, classpath, &imports, owner, &mut output)?;
        }
        if let Some(companion) = &interface.companion {
            for property in &companion.fields {
                property_visibility_annotations(
                    &property.annotations,
                    property.visibility(),
                    property.setter_visibility(),
                    !property.body.is_empty(),
                    property.setter.is_some(),
                    property.internal
                        || property.getter_visibility.is_some()
                        || property.setter_visibility.is_some(),
                    classpath,
                    &imports,
                )?;
            }
            if companion
                .properties
                .iter()
                .any(|property| !property.annotations.is_empty())
                || companion
                    .fields
                    .iter()
                    .any(|property| !property.annotations.is_empty())
            {
                return Err(Diagnostic::new(
                    interface.offset,
                    "Annotations on interface companion properties are not supported",
                )
                .with_kind(
                    crate::DiagnosticKind::UnsupportedLanguage,
                    "ANNOTATION_INTERFACE_COMPANION_PROPERTY_UNSUPPORTED",
                ));
            }
        }
    } else if let Some(enumeration) = &module.enum_decl {
        imports.insert(enumeration.name.clone(), owner.into());
        output.annotations = checked(
            owner,
            &enumeration.annotations,
            classpath,
            &imports,
            "TYPE",
            None,
        )?;
        constructor_parameters(
            owner,
            &enumeration.body,
            true,
            classpath,
            &imports,
            &mut output,
        )?;
        for method in &enumeration.body.methods {
            function_parameters(&method.function, classpath, &imports, owner, &mut output)?;
        }
        for property in &enumeration.body.properties {
            property_annotations(
                owner,
                &property.annotations,
                &property.name,
                &property.ty,
                property.mutable,
                property.private,
                property.initializer.is_some()
                    || property.lateinit
                    || property.body.is_empty() && property.delegate.is_none(),
                classpath,
                &imports,
                &mut output,
            )?;
        }
    } else {
        for property in &module.properties {
            property_visibility_annotations(
                &property.annotations,
                property.visibility(),
                property.setter_visibility(),
                !property.body.is_empty(),
                property.setter.is_some(),
                property.internal
                    || property.getter_visibility.is_some()
                    || property.setter_visibility.is_some(),
                classpath,
                &imports,
            )?;
            property_annotations(
                owner,
                &property.annotations,
                &property.name,
                &property.ty,
                property.mutable,
                property.private,
                property.initializer.is_some()
                    || property.lateinit
                    || property.body.is_empty() && property.delegate.is_none(),
                classpath,
                &imports,
                &mut output,
            )?;
        }
        for function in &module.functions {
            function_parameters(function, classpath, &imports, owner, &mut output)?;
        }
    }
    for constant in &module.constants {
        let annotations = checked(
            owner,
            &constant.annotations,
            classpath,
            &imports,
            "FIELD",
            None,
        )?;
        if !annotations.is_empty() {
            let (ty, _) = constant_expr(&constant.value)?;
            member(&mut output.fields, &constant.name, &ty.descriptor())
                .annotations
                .extend(annotations);
        }
    }
    result.insert(owner.into(), output);
    Ok(result)
}

#[allow(clippy::too_many_arguments)]
fn property_visibility_annotations(
    annotations: &[syntax::AnnotationUse],
    visibility: syntax::PropertyVisibility,
    setter_visibility: syntax::PropertyVisibility,
    custom_getter: bool,
    custom_setter: bool,
    modified: bool,
    classpath: &Classpath,
    imports: &HashMap<String, String>,
) -> Result<()> {
    if !modified {
        return Ok(());
    }
    for annotation in annotations {
        let owner = annotations::annotation_owner(&annotation.name, classpath, imports);
        if owner == "kotlin/jvm/JvmField"
            && (setter_visibility != visibility || custom_getter || custom_setter)
        {
            return Err(Diagnostic::new(
                annotation.offset,
                "JvmField cannot expose a property with a restricted or custom accessor",
            )
            .with_kind(
                crate::DiagnosticKind::InvalidKotlin,
                "JVM_FIELD_RESTRICTED_ACCESSOR",
            ));
        }
        if matches!(
            owner.as_str(),
            "kotlin/jvm/JvmField" | "kotlin/jvm/JvmStatic"
        ) {
            return Err(Diagnostic::new(annotation.offset, "JVM ABI markers combined with independent accessor or internal property visibility are unsupported").with_kind(crate::DiagnosticKind::UnsupportedLanguage, "PROPERTY_VISIBILITY_ABI_ANNOTATION_UNSUPPORTED"));
        }
        if matches!(
            annotation.use_site.as_deref(),
            Some("get" | "set" | "setparam")
        ) {
            return Err(Diagnostic::new(annotation.offset, "Accessor-target annotations combined with independent accessor or internal property visibility are unsupported").with_kind(crate::DiagnosticKind::UnsupportedLanguage, "PROPERTY_VISIBILITY_ANNOTATION_UNSUPPORTED"));
        }
    }
    Ok(())
}

fn checked(
    owner: &str,
    annotations: &[syntax::AnnotationUse],
    classpath: &Classpath,
    imports: &HashMap<String, String>,
    target: &str,
    use_site: Option<&str>,
) -> Result<Vec<DeclarationAnnotation>> {
    annotations::declaration_annotations(
        annotations,
        classpath,
        imports,
        target,
        use_site,
        Some(owner),
    )
}

fn member<'a>(
    members: &'a mut Vec<MemberAnnotations>,
    name: &str,
    descriptor: &str,
) -> &'a mut MemberAnnotations {
    let index = members
        .iter()
        .position(|member| member.name == name && member.descriptor == descriptor)
        .unwrap_or_else(|| {
            members.push(MemberAnnotations {
                synthetic_property: false,
                name: name.into(),
                descriptor: descriptor.into(),
                annotations: Vec::new(),
                parameters: Vec::new(),
            });
            members.len() - 1
        });
    &mut members[index]
}

fn constructor_parameters(
    owner: &str,
    class: &syntax::ClassDecl,
    enumeration: bool,
    classpath: &Classpath,
    imports: &HashMap<String, String>,
    output: &mut ClassAnnotations,
) -> Result<()> {
    let mut parameters = vec![Vec::new(); class.params.len() + if enumeration { 2 } else { 0 }];
    for (index, ((name, ty), annotations)) in class
        .params
        .iter()
        .zip(&class.param_annotations)
        .enumerate()
    {
        let is_property = class.param_properties.contains(name);
        let mutable = class.mutable_params.contains(name);
        let mut parameter = Vec::new();
        let mut property = Vec::new();
        for annotation in annotations {
            match annotation.use_site.as_deref() {
                Some("param") => parameter.push(annotation.clone()),
                Some(_) if is_property => property.push(annotation.clone()),
                Some(_) => {
                    return Err(Diagnostic::new(
                        annotation.offset,
                        "Annotation use-site target requires a constructor property",
                    )
                    .with_kind(
                        crate::DiagnosticKind::InvalidKotlin,
                        "ANNOTATION_CONSTRUCTOR_PROPERTY_REQUIRED",
                    ));
                }
                None => {
                    let owner = imports.get(&annotation.name).unwrap_or(&annotation.name);
                    let definition =
                        classpath
                            .load(owner)?
                            .annotation_definition
                            .ok_or_else(|| {
                                Diagnostic::new(
                                    annotation.offset,
                                    "Unsupported annotation definition",
                                )
                            })?;
                    if definition
                        .targets
                        .iter()
                        .any(|target| target == "PARAMETER")
                    {
                        parameter.push(annotation.clone());
                    } else if is_property {
                        property.push(annotation.clone());
                    } else {
                        return Err(Diagnostic::new(
                            annotation.offset,
                            "Annotation cannot target a constructor parameter",
                        )
                        .with_kind(
                            crate::DiagnosticKind::InvalidKotlin,
                            "ANNOTATION_TARGET_INVALID",
                        ));
                    }
                }
            }
        }
        let mut checked_parameter = Vec::new();
        let mut seen_parameters = HashSet::new();
        for annotation in parameter {
            let identity = imports.get(&annotation.name).unwrap_or(&annotation.name);
            if !seen_parameters.insert(identity.clone()) {
                return Err(Diagnostic::new(
                    annotation.offset,
                    "Repeated parameter annotations require a repeatable declaration",
                )
                .with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "REPEATED_ANNOTATION_INVALID",
                ));
            }
            let site = annotation.use_site.clone();
            checked_parameter.extend(checked(
                owner,
                &[annotation],
                classpath,
                imports,
                "PARAMETER",
                site.as_deref(),
            )?);
        }
        parameters[index + if enumeration { 2 } else { 0 }] = checked_parameter;
        if is_property {
            property_annotations(
                owner,
                &property,
                name,
                ty,
                mutable,
                !class.public_params.contains(name),
                true,
                classpath,
                imports,
                output,
            )?;
        }
    }
    if parameters.iter().any(|parameter| !parameter.is_empty()) {
        let descriptor = format!(
            "({}{})V",
            if enumeration {
                "Ljava/lang/String;I"
            } else {
                ""
            },
            class
                .params
                .iter()
                .map(|(_, ty)| resolve_type(ty, imports, class.offset).map(|ty| ty.descriptor()))
                .collect::<Result<Vec<_>>>()?
                .concat()
        );
        member(&mut output.methods, "<init>", &descriptor).parameters = parameters;
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn property_annotations(
    owner: &str,
    annotations: &[syntax::AnnotationUse],
    name: &str,
    ty: &Type,
    mutable: bool,
    private: bool,
    has_backing_field: bool,
    classpath: &Classpath,
    imports: &HashMap<String, String>,
    output: &mut ClassAnnotations,
) -> Result<()> {
    let ty = resolve_type(
        ty,
        imports,
        annotations
            .first()
            .map_or(0, |annotation| annotation.offset),
    )?;
    let mut seen = HashSet::new();
    for original in annotations {
        let mut placed = original.clone();
        if placed.use_site.is_none() {
            let canonical = crate::annotation_declarations::owner(&placed.name, imports, classpath);
            if classpath
                .load(&canonical)?
                .annotation_definition
                .is_some_and(|definition| {
                    definition
                        .kotlin_targets
                        .is_some_and(|targets| targets.iter().any(|target| target == "PROPERTY"))
                })
            {
                placed.use_site = Some("property".into());
            }
        }
        let annotation = &placed;
        let site = annotation.use_site.clone();
        let target = site.as_deref().unwrap_or("field");
        let identity = imports.get(&annotation.name).unwrap_or(&annotation.name);
        if !seen.insert((target.to_owned(), identity.clone())) {
            return Err(Diagnostic::new(
                annotation.offset,
                "Repeated property annotations require a repeatable declaration",
            )
            .with_kind(
                crate::DiagnosticKind::InvalidKotlin,
                "REPEATED_ANNOTATION_INVALID",
            ));
        }
        match site.as_deref() {
            Some("property") => {
                let values = checked(
                    owner,
                    std::slice::from_ref(annotation),
                    classpath,
                    imports,
                    "PROPERTY",
                    site.as_deref(),
                )?;
                if !values.is_empty() {
                    let method = member(
                        &mut output.methods,
                        &format!("{}$annotations", getter_name(name)),
                        "()V",
                    );
                    method.synthetic_property = true;
                    method.annotations.extend(values);
                }
            }
            Some("field") | None => {
                if !has_backing_field {
                    return Err(Diagnostic::new(
                        annotation.offset,
                        "Field annotation requires a property backing field",
                    )
                    .with_kind(
                        crate::DiagnosticKind::InvalidKotlin,
                        "ANNOTATION_BACKING_FIELD_REQUIRED",
                    ));
                }
                let values = checked(
                    owner,
                    std::slice::from_ref(annotation),
                    classpath,
                    imports,
                    "FIELD",
                    site.as_deref(),
                )?;
                if !values.is_empty() {
                    member(&mut output.fields, name, &ty.descriptor())
                        .annotations
                        .extend(values);
                }
            }
            Some("get") | Some("set") | Some("setparam") => {
                if private {
                    return Err(Diagnostic::new(
                        annotation.offset,
                        "Annotations on private property accessors are not supported",
                    )
                    .with_kind(
                        crate::DiagnosticKind::UnsupportedLanguage,
                        "ANNOTATION_PRIVATE_ACCESSOR_UNSUPPORTED",
                    ));
                }
                if site.as_deref() != Some("get") && !mutable {
                    return Err(Diagnostic::new(
                        annotation.offset,
                        "Setter annotation requires a mutable property",
                    )
                    .with_kind(
                        crate::DiagnosticKind::InvalidKotlin,
                        "ANNOTATION_SETTER_REQUIRES_VAR",
                    ));
                }
                let getter = site.as_deref() == Some("get");
                let descriptor = if getter {
                    format!("(){}", ty.descriptor())
                } else {
                    format!("({})V", ty.descriptor())
                };
                let method_name = if getter {
                    getter_name(name)
                } else {
                    setter_name(name)
                };
                let parameter = site.as_deref() == Some("setparam");
                let values = checked(
                    owner,
                    std::slice::from_ref(annotation),
                    classpath,
                    imports,
                    if parameter { "PARAMETER" } else { "METHOD" },
                    site.as_deref(),
                )?;
                if !values.is_empty() {
                    let method = member(&mut output.methods, &method_name, &descriptor);
                    if parameter {
                        if method.parameters.is_empty() {
                            method.parameters.push(Vec::new());
                        }
                        method.parameters[0].extend(values);
                    } else {
                        method.annotations.extend(values);
                    }
                }
            }
            _ => {
                return Err(Diagnostic::new(
                    annotation.offset,
                    "Invalid annotation use-site target for property",
                )
                .with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "ANNOTATION_USE_SITE_INVALID",
                ));
            }
        }
    }
    Ok(())
}

fn function_parameters(
    function: &syntax::Function,
    classpath: &Classpath,
    imports: &HashMap<String, String>,
    owner: &str,
    output: &mut ClassAnnotations,
) -> Result<()> {
    if function.param_annotations.iter().all(Vec::is_empty) {
        return Ok(());
    }
    let mut params = Vec::new();
    let mut descriptor = String::from("(");
    if let Some(receiver) = &function.receiver {
        descriptor.push_str(&resolve_type(receiver, imports, function.offset)?.descriptor());
        params.push(Vec::new());
    }
    for ((_, ty), annotations) in function.params.iter().zip(&function.param_annotations) {
        descriptor.push_str(&resolve_type(ty, imports, function.offset)?.descriptor());
        params.push(checked(
            owner,
            annotations,
            classpath,
            imports,
            "PARAMETER",
            None,
        )?);
    }
    descriptor.push(')');
    descriptor.push_str(&resolve_type(&function.result, imports, function.offset)?.descriptor());
    let name = classpath
        .load(owner)?
        .methods
        .iter()
        .find(|method| {
            method.descriptor == descriptor
                && (method.name == function.name
                    || method
                        .library
                        .as_ref()
                        .is_some_and(|library| library.source_name == function.name))
        })
        .map(|method| method.name.clone())
        .unwrap_or_else(|| function.name.clone());
    member(&mut output.methods, &name, &descriptor).parameters = params;
    if checked(
        owner,
        &function.annotations,
        classpath,
        imports,
        "METHOD",
        None,
    )?
    .iter()
    .any(|annotation| annotation.descriptor == "Lkotlin/jvm/JvmOverloads;")
    {
        let mut omitted = HashSet::new();
        for index in (0..function.params.len()).rev() {
            if !function.defaults.get(index).is_some_and(Option::is_some) {
                continue;
            }
            omitted.insert(index);
            let mut descriptor = String::from("(");
            let mut parameters = Vec::new();
            if let Some(receiver) = &function.receiver {
                descriptor
                    .push_str(&resolve_type(receiver, imports, function.offset)?.descriptor());
                parameters.push(Vec::new());
            }
            for (index, ((_, ty), annotations)) in function
                .params
                .iter()
                .zip(&function.param_annotations)
                .enumerate()
            {
                if omitted.contains(&index) {
                    continue;
                }
                descriptor.push_str(&resolve_type(ty, imports, function.offset)?.descriptor());
                parameters.push(checked(
                    owner,
                    annotations,
                    classpath,
                    imports,
                    "PARAMETER",
                    None,
                )?);
            }
            descriptor.push(')');
            descriptor
                .push_str(&resolve_type(&function.result, imports, function.offset)?.descriptor());
            member(&mut output.methods, &name, &descriptor).parameters = parameters;
        }
    }
    Ok(())
}
