use super::*;

fn unsupported(offset: usize, message: &str) -> Diagnostic {
    Diagnostic::new(offset, message).with_kind(
        crate::DiagnosticKind::UnsupportedLanguage,
        "ANONYMOUS_OBJECT_SHAPE_UNSUPPORTED",
    )
}

impl Checker<'_> {
    pub(super) fn anonymous_object(
        &mut self,
        supertypes: &[(Type, Option<Vec<Expr>>)],
        methods: &[syntax::Function],
        offset: usize,
    ) -> Result<Value> {
        let owner = format!(
            "{}$object${}${}",
            self.lambda_owner,
            offset,
            self.lambdas.borrow().len()
        );
        let mut parent = "java/lang/Object".to_string();
        let mut interfaces = Vec::new();
        let mut super_arguments = Vec::new();
        let mut super_descriptor = "()V".to_string();
        let mut inherited = Vec::new();
        let mut conflicts = HashSet::new();
        let mut has_parent = false;
        let mut primary = None;
        for (supertype, arguments) in supertypes {
            let ty = self.resolve(supertype, offset)?;
            let Type::Java(super_owner) = &ty else {
                return Err(unsupported(
                    offset,
                    "Generic anonymous supertypes are unsupported",
                ));
            };
            let class = self.classpath.load(super_owner)?;
            if class.sealed_ {
                return Err(Diagnostic::new(
                    offset,
                    "Anonymous objects cannot inherit sealed classifiers",
                )
                .with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "SEALED_ANONYMOUS_SUBCLASS_INVALID",
                ));
            }
            if class.access & 0x2000 != 0
                || class
                    .library
                    .as_ref()
                    .is_some_and(|library| !library.type_parameters.is_empty())
            {
                return Err(unsupported(
                    offset,
                    "Generic and annotation anonymous supertypes are unsupported",
                ));
            }
            if !self
                .classpath
                .classifier_visible(&self.lambda_owner, super_owner)
            {
                return Err(
                    Diagnostic::new(offset, "Anonymous supertype is inaccessible").with_kind(
                        crate::DiagnosticKind::InvalidKotlin,
                        "INACCESSIBLE_CLASSIFIER",
                    ),
                );
            }
            if class.access & 0x0200 != 0 {
                if arguments.is_some() || interfaces.contains(super_owner) {
                    return Err(
                        Diagnostic::new(offset, "Invalid anonymous interface supertype").with_kind(
                            crate::DiagnosticKind::InvalidKotlin,
                            "ANONYMOUS_SUPERTYPE_INVALID",
                        ),
                    );
                }
                interfaces.push(super_owner.clone());
            } else {
                if has_parent || arguments.is_none() || class.access & 0x0010 != 0 {
                    return Err(Diagnostic::new(
                        offset,
                        "Anonymous class requires one nonfinal superclass constructor",
                    )
                    .with_kind(
                        crate::DiagnosticKind::InvalidKotlin,
                        "ANONYMOUS_SUPERTYPE_INVALID",
                    ));
                }
                has_parent = true;
                parent = super_owner.clone();
                let constructors = class
                    .methods
                    .iter()
                    .filter(|m| m.name == "<init>" && m.access & 5 != 0)
                    .cloned()
                    .collect::<Vec<_>>();
                let arguments = arguments.as_ref().unwrap();
                let method = self.select_method(&constructors, arguments, offset)?;
                let (types, _) = class_method_types(&method)?;
                let params = method
                    .kotlin_params
                    .as_ref()
                    .map(|params| {
                        params
                            .iter()
                            .map(|p| (p.0.clone(), p.1.clone()))
                            .collect::<Vec<_>>()
                    })
                    .unwrap_or_else(|| {
                        types
                            .iter()
                            .cloned()
                            .enumerate()
                            .map(|(i, t)| (format!("p{i}"), java_parameter(t)))
                            .collect()
                    });
                if arguments.len() < params.len()
                    && method
                        .kotlin_params
                        .as_ref()
                        .is_some_and(|params| params.iter().any(|p| p.2))
                {
                    return Err(unsupported(
                        offset,
                        "Default anonymous superclass arguments are unsupported",
                    ));
                }
                let (args, lets, mask) = self.arguments(
                    &params,
                    &vec![false; params.len()],
                    arguments,
                    method.kotlin_params.is_some(),
                    offset,
                )?;
                if !lets.is_empty() || mask != 0 {
                    return Err(unsupported(
                        offset,
                        "Reordered and default anonymous superclass arguments are unsupported",
                    ));
                }
                super_arguments = args
                    .into_iter()
                    .zip(types)
                    .map(|(value, ty)| self.coerce(value, java_parameter(ty), offset))
                    .collect::<Result<Vec<_>>>()?;
                super_descriptor = method.descriptor;
            }
            primary.get_or_insert(ty.clone());
            for method in self
                .classpath
                .ordinary_methods(super_owner)?
                .into_iter()
                .filter(|method| {
                    method.access & 0x0008 == 0 && method.access & 5 != 0 && method.name != "<init>"
                })
            {
                if let Some(other) = inherited.iter().find(|other: &&JavaMethod| {
                    other.name == method.name && other.descriptor == method.descriptor
                }) {
                    let concrete = |method: &JavaMethod| {
                        method.access & 0x0400 == 0
                            || method
                                .library
                                .as_ref()
                                .is_some_and(|library| !library.abstract_)
                    };
                    if other.owner != method.owner && (concrete(other) || concrete(&method)) {
                        conflicts.insert((method.name.clone(), method.descriptor.clone()));
                    }
                } else {
                    inherited.push(method);
                }
            }
        }
        if inherited.iter().any(|method| {
            method.access & 0x0400 != 0
                && (method.source_property.is_some()
                    || method
                        .library
                        .as_ref()
                        .is_some_and(|library| !library.type_parameters.is_empty()))
        }) {
            return Err(unsupported(
                offset,
                "Anonymous inherited properties and generic methods are unsupported",
            ));
        }
        self.classpath.register_source(crate::classpath::JavaClass {
            name: owner.clone(),
            access: 0x0031,
            super_name: Some(parent.clone()),
            interfaces: interfaces.clone(),
            methods: Vec::new(),
            fields: Vec::new(),
            sealed_: false,
            sealed_subclasses: Vec::new(),
            annotation_definition: None,
            kotlin_fun_interface: false,
            library: None,
            kotlin_class: false,
            unsupported: false,
            kotlin_interface: false,
        });
        self.classpath
            .register_lexical_parent(&owner, &self.lambda_owner);
        let interface = primary.unwrap();
        let mut selected = Vec::new();
        let mut seen = HashSet::new();
        for source in methods {
            if source.suspend_
                || source.inline
                || source.vararg
                || source.receiver.is_some()
                || !source.type_params.is_empty()
                || !source.annotations.is_empty()
                || source
                    .param_annotations
                    .iter()
                    .any(|annotations| !annotations.is_empty())
                || source.defaults.iter().any(Option::is_some)
            {
                return Err(unsupported(
                    source.offset,
                    "Anonymous override modifiers, generics, annotations and defaults are unsupported",
                ));
            }
            let params = source
                .params
                .iter()
                .map(|(name, ty)| Ok((name.clone(), self.resolve(ty, source.offset)?)))
                .collect::<Result<Vec<_>>>()?;
            let candidates = inherited
                .iter()
                .filter(|method| method.source_name() == source.name)
                .filter(|method| {
                    class_method_types(method).is_ok_and(|(types, _)| {
                        types == params.iter().map(|p| p.1.clone()).collect::<Vec<_>>()
                    })
                })
                .collect::<Vec<_>>();
            if candidates.len() != 1 {
                let prefix = format!(
                    "({})",
                    params.iter().map(|p| p.1.descriptor()).collect::<String>()
                );
                if inherited.iter().any(|method| {
                    method.source_name() == source.name && method.descriptor.starts_with(&prefix)
                }) {
                    return Err(unsupported(
                        source.offset,
                        "Anonymous platform/nullability signature adaptation is unsupported",
                    ));
                }

                return Err(Diagnostic::new(
                    source.offset,
                    "Anonymous override requires an exact inherited method signature",
                )
                .with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "ANONYMOUS_OVERRIDE_MISMATCH",
                ));
            }
            let method = candidates[0].clone();
            if method.access & 0x0010 != 0 {
                return Err(
                    Diagnostic::new(source.offset, "Cannot override a final member").with_kind(
                        crate::DiagnosticKind::InvalidKotlin,
                        "FINAL_MEMBER_OVERRIDE",
                    ),
                );
            }
            if !seen.insert((method.name.clone(), method.descriptor.clone())) {
                return Err(
                    Diagnostic::new(source.offset, "Duplicate anonymous override").with_kind(
                        crate::DiagnosticKind::InvalidKotlin,
                        "ANONYMOUS_OVERRIDE_DUPLICATE",
                    ),
                );
            }
            let (_, result) = class_method_types(&method)?;
            if !source.result_inferred {
                let declared_result = self.resolve(&source.result, source.offset)?;
                if declared_result != result {
                    if method.kotlin_result.is_none()
                        && declared_result.descriptor() == result.descriptor()
                    {
                        return Err(unsupported(
                            source.offset,
                            "Anonymous Java platform result adaptation is unsupported",
                        ));
                    }
                    if self.subtype(&declared_result, &result)
                        || result == Type::Java("java/lang/Object".into())
                    {
                        return Err(unsupported(
                            source.offset,
                            "Covariant anonymous override results are unsupported",
                        ));
                    }
                    return Err(Diagnostic::new(
                        source.offset,
                        "Anonymous override result differs from inherited method",
                    )
                    .with_kind(
                        crate::DiagnosticKind::InvalidKotlin,
                        "ANONYMOUS_OVERRIDE_RESULT_MISMATCH",
                    ));
                }
            }
            if format!(
                "({}){}",
                params.iter().map(|p| p.1.descriptor()).collect::<String>(),
                result.descriptor()
            ) != method.descriptor
            {
                return Err(unsupported(
                    source.offset,
                    "Anonymous override requiring erased bridges is unsupported",
                ));
            }
            selected.push((source, params, result, method));
        }
        if conflicts.iter().any(|signature| !seen.contains(signature)) {
            return Err(unsupported(
                offset,
                "Conflicting anonymous inherited defaults require an explicit override",
            ));
        }
        for required in &inherited {
            let abstract_ = required.access & 0x0400 != 0
                && required
                    .library
                    .as_ref()
                    .is_none_or(|library| library.abstract_);
            if abstract_ && !seen.contains(&(required.name.clone(), required.descriptor.clone())) {
                return Err(Diagnostic::new(
                    offset,
                    "Anonymous object does not implement every abstract method",
                )
                .with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "ANONYMOUS_ABSTRACT_MEMBER_MISSING",
                ));
            }
        }
        let mut names = HashSet::new();
        for source in methods {
            let parameters = source
                .params
                .iter()
                .map(|p| p.0.clone())
                .chain(std::iter::once("this".into()))
                .collect::<Vec<_>>();
            names.extend(captures::free_names(&source.body, &parameters));
        }
        if parent == "java/lang/Object"
            && names
                .iter()
                .any(|name| name == "super" || name.starts_with("super@"))
        {
            return Err(unsupported(
                offset,
                "Anonymous interface super calls are unsupported",
            ));
        }
        names.retain(|name| {
            !name.starts_with("this@")
                && (self.local(name).is_some() || self.captured.contains_key(name))
        });
        let mut names = names.into_iter().collect::<Vec<_>>();
        names.sort();
        let mut fields = super_arguments
            .iter()
            .enumerate()
            .map(|(index, value)| (format!("$super${index}"), value.ty.clone()))
            .collect::<Vec<_>>();
        let super_types = super_arguments
            .iter()
            .map(|value| value.ty.clone())
            .collect();
        let mut values = super_arguments;
        let mut captured = HashMap::new();
        let mut captured_cells = HashMap::new();
        let mut readonly = Vec::new();
        for name in names {
            if self
                .local(&name)
                .is_some_and(|local| !self.initialized.contains(&local.slot))
            {
                return Err(Diagnostic::new(
                    offset,
                    "Variable must be initialized before anonymous capture",
                )
                .with_kind(
                    crate::DiagnosticKind::InvalidKotlin,
                    "ANONYMOUS_CAPTURE_UNINITIALIZED",
                ));
            }
            let value = if let Some((cell, ty)) = self.cell_binding(&name) {
                if self.cell_is_readonly(&name) {
                    readonly.push(name.clone());
                }
                captured_cells.insert(name.clone(), ty);
                cell
            } else {
                if self.local(&name).is_some_and(|local| local.mutable) {
                    return Err(unsupported(
                        offset,
                        "Mutable anonymous capture requires an enclosing initialized local",
                    ));
                }
                self.value(&Expr {
                    offset,
                    kind: ExprKind::Name(name.clone()),
                })?
            };
            captured.insert(name.clone(), (owner.clone(), value.ty.clone()));
            fields.push((name, value.ty.clone()));
            values.push(value);
        }
        let mut receivers = self
            .extension_receivers
            .iter()
            .cloned()
            .map(|local| (false, Some(local.clone()), Self::local_receiver(&local)))
            .collect::<Vec<_>>();
        if let Ok(value) = self.dispatch_receiver_value(offset) {
            receivers.push((true, self.dispatch_receiver.clone(), value));
        }
        let mut receiver_fields = Vec::new();
        for (index, (dispatch, local, value)) in receivers.into_iter().enumerate() {
            let mut ordinal = index;
            let name = loop {
                let candidate = format!("$outer${ordinal}");
                if !fields.iter().any(|(name, _)| name == &candidate) {
                    break candidate;
                }
                ordinal += 1;
            };
            let mut labels = local
                .as_ref()
                .map(|local| {
                    self.receiver_labels
                        .iter()
                        .filter(|(_, other)| local.slot == other.slot && local.ty == other.ty)
                        .map(|(name, _)| name.clone())
                        .collect::<Vec<_>>()
                })
                .unwrap_or_default();
            if dispatch {
                if let Some(label) =
                    library::type_owner(&value.ty).and_then(|owner| owner.rsplit(['/', '$']).next())
                {
                    labels.push(label.to_string());
                }
            }
            receiver_fields.push((dispatch, name.clone(), value.ty.clone(), labels));
            fields.push((name, value.ty.clone()));
            values.push(value);
        }
        let mut implementations = Vec::new();
        for (source, params, result, method) in selected {
            let mut checker = Checker {
                inline_argument_modes: Vec::new(),
                inline_analysis: false,
                public_inline_body: self.public_inline_body,
                constructor_bridge_context: true,
                reified_parameters: Vec::new(),
                exhaustiveness_flow: false,
                extension_receivers: vec![Local {
                    slot: 0,
                    ty: Type::Java(owner.clone()),
                    mutable: false,
                }],
                receiver_labels: HashMap::new(),
                lambdas: self.lambdas.clone(),
                captured: captured.clone(),
                captured_cells: captured_cells.clone(),
                cells: HashMap::new(),
                cell_names: HashSet::new(),
                lambda_owner: owner.clone(),
                inline_result: None,
                nonlocal_result: None,
                classpath: self.classpath,
                constants: self.constants,
                constructor: self.constructor,
                defaults: self.defaults,
                function_names: self.function_names,
                mutable_fields: self.mutable_fields,
                extensions: self.extensions,
                classes: self.classes,
                imports: self.imports,
                signatures: self.signatures,
                source_type_params: self.source_type_params,
                source_infix: self.source_infix,
                source_operator: self.source_operator,
                dispatch_receiver: if parent != "java/lang/Object" {
                    Some(Local {
                        slot: 0,
                        ty: Type::Java(owner.clone()),
                        mutable: false,
                    })
                } else {
                    None
                },
                fields: self.fields,
                members: self.members,
                companion_fields: self.companion_fields,
                functions: self.functions,
                object_methods: self.object_methods,
                object_fields: self.object_fields,
                object_owner: self.object_owner,
                allow_return: true,
                contract_facts: HashMap::new(),
                contract_registration: None,
                refinements: HashMap::new(),
                initialized: HashSet::from([0]),
                loop_depth: 0,
                scopes: vec![HashMap::new()],
                next: 1,
                result: result.clone(),
            };
            for name in &readonly {
                checker.scopes[0].insert(
                    format!("<readonlyCell:{name}>"),
                    Local {
                        slot: 0,
                        ty: Type::Unit,
                        mutable: false,
                    },
                );
            }
            for (name, ty) in &params {
                checker.declare(name, ty.clone(), false, source.offset)?;
            }
            let mut setup = Vec::new();
            for (dispatch, name, ty, labels) in &receiver_fields {
                let slot = checker.allocate_typed_slot(ty, offset)?;
                checker.initialized.insert(slot);
                let local = Local {
                    slot,
                    ty: ty.clone(),
                    mutable: false,
                };
                if *dispatch && parent == "java/lang/Object" {
                    checker.dispatch_receiver = Some(local.clone());
                } else {
                    checker.extension_receivers.push(local.clone());
                }
                for label in labels {
                    checker.receiver_labels.insert(label.clone(), local.clone());
                }
                setup.push(Statement::Store(
                    slot,
                    Value {
                        ty: ty.clone(),
                        kind: ValueKind::JavaField {
                            descriptor: None,
                            owner: owner.clone(),
                            name: name.clone(),
                            receiver: Some(Box::new(Value {
                                ty: Type::Java(owner.clone()),
                                kind: ValueKind::Local(0),
                            })),
                        },
                    },
                ));
            }
            if source.result_inferred {
                let [
                    syntax::Statement {
                        kind: StatementKind::Return(Some(expression)),
                        ..
                    },
                ] = source.body.as_slice()
                else {
                    return Err(unsupported(
                        source.offset,
                        "Anonymous inferred result shape is unsupported",
                    ));
                };
                if control::expression_terminates(expression) {
                    return Err(unsupported(
                        source.offset,
                        "Anonymous Nothing result inference is unsupported",
                    ));
                }
                let mut probe = checker.clone();
                let saved_count = checker.lambdas.borrow().len();
                let inferred = probe.value(expression);
                checker.lambdas.borrow_mut().truncate(saved_count);
                let inferred = inferred?;
                if inferred.ty != result {
                    if checker.subtype(&inferred.ty, &result)
                        || result == Type::Java("java/lang/Object".into())
                    {
                        return Err(unsupported(
                            source.offset,
                            "Covariant anonymous inferred results are unsupported",
                        ));
                    }
                    return Err(Diagnostic::new(
                        source.offset,
                        "Anonymous inferred result differs from inherited method",
                    )
                    .with_kind(
                        crate::DiagnosticKind::InvalidKotlin,
                        "ANONYMOUS_OVERRIDE_RESULT_MISMATCH",
                    ));
                }
            }
            let (mut body, returns) = checker.block(&source.body)?;
            if !returns {
                if result != Type::Unit {
                    return Err(Diagnostic::new(
                        source.offset,
                        "Anonymous method must return a value",
                    ));
                }
                body.push(Statement::Return(Value {
                    ty: Type::Unit,
                    kind: ValueKind::Unit,
                }));
            }
            setup.append(&mut body);
            implementations.push(Function {
                suspend_: false,
                extension_receiver: false,
                class_type_params: Vec::new(),
                jvm_result: None,
                jvm_signature: None,
                jvm_name: Some(method.name),
                annotations: Vec::new(),
                vararg: false,
                type_params: Vec::new(),
                defaults: params.iter().map(|_| None).collect(),
                name: source.name.clone(),
                private: false,
                is_override: true,
                params,
                result,
                locals: checker.next,
                body: setup,
            });
        }
        let first = implementations.first().cloned().unwrap_or(Function {
            suspend_: false,
            extension_receiver: false,
            class_type_params: Vec::new(),
            jvm_result: None,
            jvm_signature: None,
            jvm_name: None,
            annotations: Vec::new(),
            vararg: false,
            type_params: Vec::new(),
            defaults: Vec::new(),
            name: "<anonymous>".into(),
            private: false,
            is_override: false,
            params: Vec::new(),
            result: Type::Unit,
            locals: 1,
            body: Vec::new(),
        });
        let defaults = inherited
            .into_iter()
            .filter(|method| {
                !seen.contains(&(method.name.clone(), method.descriptor.clone()))
                    && method.access & 0x0400 != 0
                    && method
                        .library
                        .as_ref()
                        .is_some_and(|library| !library.abstract_)
            })
            .collect();
        self.lambdas.borrow_mut().push(LambdaDecl {
            anonymous_methods: Some(implementations),
            anonymous_super: Some(AnonymousSuper {
                owner: parent,
                descriptor: super_descriptor,
                params: super_types,
                interfaces,
            }),
            defaults,
            owner: owner.clone(),
            captures: fields,
            function: first,
            interface: None,
        });
        Ok(Value {
            ty: if supertypes.len() == 1 {
                interface
            } else {
                Type::Java(owner.clone())
            },
            kind: ValueKind::Lambda {
                owner,
                captures: values,
            },
        })
    }
}
