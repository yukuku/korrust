package compatibility.declarations.consumer
import compatibility.declarations.*
fun main() {
    val mapper = Mapper { value -> value * 3 }
    check(mapper.apply(4) == 12 && mapper.twice(4) == 24)
    check(newMapper(5).apply(8) == 13)
    val captured = capturedMapper(2)
    check(captured.apply(3) == 5 && captured.apply(4) == 9)
    check(captured.twice(1) == 21 && captured.apply(0) == 11)
    check(capturedSink("p") == "p:one;p:two;")
    check(distinguishTypes() == "sam:function")
    println("OK")
}
