# Diagnostic boundary replay

These scripts are focused regression proofs for the three repair patches. They do not add generic value-class, private class, suspend member, package-private class-literal, annotation, Android or full-app support.

From the Korrust repository root, after integrating the reviewed patches and building its compiler, extract boundary-replay.zip into target/diagnostic-boundary-replay and use fresh output names:

```sh
export JAVA_HOME=/Users/yuku/Library/Java/JavaVirtualMachines/jbr-21.0.8/Contents/Home
python3 target/diagnostic-boundary-replay/check_diagnostic_boundaries.py --root . --candidate target/resume-root-build/release/korrust --fixtures target/diagnostic-boundary-replay/fixtures --output target/diagnostic-boundaries-fresh
python3 target/diagnostic-boundary-replay/check_generic_value_extension_boundaries.py --root . --candidate target/resume-root-build/release/korrust --fixtures target/diagnostic-boundary-replay/fixtures --output target/generic-value-extension-boundaries-fresh
```

Each script requires a new output directory, uses the pinned installed Kotlin compiler/stdlib under references/kotlinc, freezes inputs and records exact argv/logs. The root option supplies compiler sources and reference pins; fixtures and candidate are explicit. No generated classfiles or compiler binaries are included in this archive.

The main proof compares supported generic reference and nongeneric value extensions, public same-package class literals, oracle-invalid types/modifiers, and oracle-valid unsupported boundaries. Fixed Java caller bytecode compiles against official output only and executes against both providers with -Xverify:all.

The adversarial proof compiles an authored generic Packet value class once with the oracle as an identical external library. Its nullable boxed factory reaches the unsupported extension boundary without adding class-import or generic-cast support. The oracle chooses the renamed Packet extension over Any; the candidate must reject without emitting the fallback. Higher-priority explicit Any extensions execute correctly despite lower-priority implicit and same-package unsupported Packet extensions. A known non-infix Packet declaration remains oracle-invalid and receives InvalidKotlin/INFIX_MODIFIER_REQUIRED. The lower-priority fixture uses the kotlin package and is compiled only as an authored dependency with -Xallow-kotlin-package; no pinned source is modified.

Java class-literal controls are context-specific. In the default package, the original full classifier spelling remains available alongside its alias. In a named package, the aliased original short name rejects; the alias and an unaliased same-package spelling work. A distinct default-package Alias class verifies that an explicit import alias retains binding priority. A foreign imported alias does not expose the hidden original spelling. Alias rejection cases assess rejection, not diagnostic-category equivalence.

Proposed tracked locations, if preferred to this archive: tools/check_diagnostic_boundaries.py, tools/check_generic_value_extension_boundaries.py and tests/fixtures/diagnostic_boundaries/. All paths are passed explicitly, so no source changes are needed when copying them there.
