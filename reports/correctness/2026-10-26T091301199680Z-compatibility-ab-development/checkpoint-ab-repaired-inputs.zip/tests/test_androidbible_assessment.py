import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import assess_androidbible as assessment


def result(code=0, stderr='', emitted=True, **kwargs):
    return {'exit_code': code, 'stderr': stderr, 'emitted_classes_sha256': {'Value.class': 'hash'} if emitted else {}, **kwargs}


class AndroidBibleAssessmentTests(unittest.TestCase):
    def test_emission_requires_classes_and_matching_oracle_acceptance(self):
        self.assertEqual(assessment.classify(result(), result()), 'emitted')
        self.assertEqual(assessment.classify(result(emitted=False), result()), 'compiler_failure')
        self.assertEqual(assessment.classify(result(), result(1, 'Value.kt:2:3: error: Type mismatch')), 'compiler_failure')

    def test_valid_unsupported_and_invalid_kotlin_are_distinct(self):
        candidate = result(1, 'Value.kt:2:3: error: Unsupported value class', emitted=False)
        self.assertEqual(assessment.classify(candidate, result()), 'unsupported_language')
        self.assertEqual(assessment.classify(candidate, result(1, 'Value.kt:2:3: error: Expecting member declaration')), 'invalid_kotlin')
        self.assertEqual(assessment.classify(result(1, 'Value.kt:2:3: error: Type mismatch'), result()), 'compiler_failure')

    def test_dependency_gap_never_claims_intrinsic_invalidity(self):
        self.assertEqual(assessment.classify(result(1, 'Expected identifier'), result(1, 'Value.kt:5:4: error: Unresolved reference: Helper')), 'dependency_failure')
        self.assertEqual(assessment.classify(result(1, 'Unresolved library class Helper'), result()), 'compiler_failure')
        self.assertEqual(assessment.classify(result(1, 'Unsupported imported declaration Helper'), result()), 'unsupported_language')
        self.assertEqual(assessment.classify(result(), result(), setup_error='Missing Android SDK'), 'setup_failure')

    def test_timeout_launch_and_compiler_crash_are_distinct(self):
        self.assertEqual(assessment.classify(result(None, timed_out=True), result()), 'timeout')
        self.assertEqual(assessment.classify(result(None, launch_error='missing binary'), result()), 'setup_failure')
        self.assertEqual(assessment.classify(result(-9), result()), 'compiler_failure')

    def test_first_diagnostic_keeps_original_location_and_multiline_body(self):
        diagnostic = assessment.first_diagnostic('warning: x\n/workspace/A.kt:27:16: error: Unsupported declaration\n    val x = 1\n')
        self.assertEqual(diagnostic, {'path': '/workspace/A.kt', 'line': 27, 'column': 16, 'message': 'Unsupported declaration'})
        self.assertEqual(assessment.first_diagnostic('e: file:///workspace/A.kt: (5, 9): Missing type')['line'], 5)
        self.assertIsNone(assessment.first_diagnostic('Compiler crashed')['line'])

    def test_source_groups_include_tests_and_tools(self):
        self.assertEqual(assessment.source_group('Module/src/main/java/Value.kt'), 'production')
        self.assertEqual(assessment.source_group('Module/src/test/java/Value.kt'), 'tests')
        self.assertEqual(assessment.source_group('Module/src/androidTest/kotlin/Value.kt'), 'tests')
        self.assertEqual(assessment.source_group('tools/script/Value.kt'), 'tools')

    def test_counts_derive_from_cases_and_preserve_not_run_behavior(self):
        cases = [{'outcome': 'emitted', 'group': 'production', 'checks': {'emission': {'outcome': 'emitted'}, 'behavior': {'outcome': 'not_run'}}}, {'outcome': 'dependency_failure', 'group': 'tests', 'checks': {'emission': {'outcome': 'not_emitted'}, 'behavior': {'outcome': 'not_run'}}}]
        counts = assessment.derived_counts(cases)
        self.assertEqual(sum(counts['outcomes'].values()), len(cases))
        self.assertEqual(counts['groups']['tests'], {'dependency_failure': 1})
        self.assertEqual(counts['behavior'], {'not_run': 2})

    def test_resolved_model_selects_exact_source_and_release_task(self):
        source = assessment.SNAPSHOT / 'Alkitab/src/main/java/Value.kt'
        task = {'sources': ['/disposable/androidbible/Alkitab/src/main/java/Value.kt'], 'compile_classpath': ['/dependency.jar']}
        model = {'modules': {'Alkitab': {'compilation_tasks': {'compileDebugKotlin': task, 'compileReleaseKotlin': task}}}}
        _, name, selected = assessment.resolved_task(model, source)
        self.assertEqual(name, 'compileReleaseKotlin')
        self.assertEqual(selected['compile_classpath'], ['/dependency.jar'])
        with self.assertRaisesRegex(ValueError, 'No resolved'):
            assessment.resolved_task(model, source.with_name('Missing.kt'))

    def test_gradle_options_keep_language_target_plugin_boundary_inputs(self):
        options = assessment.official_options({'jvmTarget': '21', 'languageVersion': '2.3', 'apiVersion': '2.3', 'javaParameters': 'true', 'allWarningsAsErrors': 'false', 'module_name': 'selected', 'freeCompilerArgs': ['-Xjvm-default=all']})
        self.assertEqual(options, ['-language-version', '2.3', '-api-version', '2.3', '-jvm-target', '21', '-module-name', 'selected', '-java-parameters', '-Xjvm-default=all'])

    def test_gradle_enum_values_from_captured_model_become_cli_values(self):
        options = assessment.official_options({'jvmTarget': 'JVM_21', 'languageVersion': 'KOTLIN_2_3', 'apiVersion': 'KOTLIN_2_3', 'jvmDefault': 'NO_COMPATIBILITY'})
        self.assertEqual(options, ['-language-version', '2.3', '-api-version', '2.3', '-jvm-target', '21', '-jvm-default', 'no-compatibility'])
        self.assertEqual(assessment.official_options({'jvmTarget': 'JVM_1_8', 'languageVersion': None, 'apiVersion': None}), ['-jvm-target', '1.8'])

    def test_comparison_names_compiler_and_classpath_changes(self):
        previous = {'compiler': {'binary_sha256': 'old'}, 'classpath_scope': 'limited', 'cases': [{'id': 'A.kt', 'source_sha256': 'same', 'outcome': 'rejected', 'diagnostic': 'A.kt:3:4: error: Missing class'}]}
        cases = [{'id': 'A.kt', 'source_sha256': 'same', 'outcome': 'unsupported_language', 'first_diagnostic': {'path': 'A.kt', 'line': 4, 'column': 5, 'message': 'Unsupported Double'}}]
        comparison = assessment.compare(previous, cases, {'binary_sha256': 'new'}, 'resolved Gradle')
        self.assertEqual(comparison['prior_classpath_scope'], 'limited')
        self.assertEqual(comparison['current_classpath_scope'], 'resolved Gradle')
        self.assertEqual(comparison['current_compiler']['binary_sha256'], 'new')
        self.assertTrue(comparison['changes'][0]['same_source'])
        self.assertEqual(comparison['changes'][0]['after']['first_diagnostic']['line'], 4)


if __name__ == '__main__':
    unittest.main()
