use super::interfaces::Builder;
use super::*;
use crate::check::{DynamicObject, ObjectField, ObjectInitializer, ObjectMethod};
use crate::metadata::Metadata;

fn add_attribute(method: &mut Vec<u8>, attribute: Vec<u8>) -> Result<()> {
    let count = u16::from_be_bytes([method[6], method[7]])
        .checked_add(1)
        .ok_or_else(|| failure("Too many method attributes"))?;
    method[6..8].copy_from_slice(&count.to_be_bytes());
    method.extend(attribute);
    Ok(())
}

fn exceptions(pool: &mut Pool, names: &[String]) -> Result<Vec<u8>> {
    let mut attribute = Vec::new();
    u2(&mut attribute, pool.utf8("Exceptions")?);
    u4(&mut attribute, (2 + 2 * names.len()) as u32);
    u2(
        &mut attribute,
        u16::try_from(names.len()).map_err(|_| failure("Too many declared exceptions"))?,
    );
    for name in names {
        u2(&mut attribute, pool.class(name)?);
    }
    Ok(attribute)
}

fn jvm_static(pool: &mut Pool) -> Result<Vec<u8>> {
    let mut attribute = Vec::new();
    u2(&mut attribute, pool.utf8("RuntimeVisibleAnnotations")?);
    u4(&mut attribute, 6);
    u2(&mut attribute, 1);
    u2(&mut attribute, pool.utf8("Lkotlin/jvm/JvmStatic;")?);
    u2(&mut attribute, 0);
    Ok(attribute)
}

fn method(
    pool: &mut Pool,
    owner: &str,
    declaration: &ObjectMethod,
    lambdas: &[crate::check::LambdaDecl],
) -> Result<Vec<u8>> {
    let function = &declaration.function;
    if declaration.inline && (!function.private || declaration.jvm_static) {
        return Err(failure(
            "Only private instance inline object methods are supported",
        ));
    }
    let mut code = Code {
        pool,
        functions: &[],
        owner,
        bytes: Vec::new(),
        labels: Vec::new(),
        branches: Vec::new(),
        loops: Vec::new(),
        loop_finally_depths: Vec::new(),
        loop_names: Vec::new(),
        pending_loop_name: None,
        finalizers: Vec::new(),
        exceptions: Vec::new(),
        temporary_count: 0,
        temporary_patches: Vec::new(),
        lambdas,
        inline_local_maps: Vec::new(),
        inline_returns: Vec::new(),
        in_lambda: false,
        max_stack: 2,
    };
    if !function.private {
        for (slot, (name, ty)) in
            parameter_slots(&function.params, usize::from(!declaration.jvm_static))
                .into_iter()
                .zip(&function.params)
        {
            if nonnull(ty) {
                code.bytes.extend([0x19, slot as u8]);
                let constant = code.pool.string(name)?;
                code.reference(0x13, constant);
                code.method_reference(
                    0xb8,
                    "kotlin/jvm/internal/Intrinsics",
                    "checkNotNullParameter",
                    "(Ljava/lang/Object;Ljava/lang/String;)V",
                )?;
            }
        }
    }
    code.block(&function.body)?;
    let max_stack =
        u16::try_from(code.max_stack).map_err(|_| failure("JVM operand stack limit exceeded"))?;
    let code = code.into_simple(function.locals, max_stack)?;
    let flags = (if function.private { 0x0002 } else { 0x0001 })
        | if function.is_override { 0 } else { 0x0010 }
        | if declaration.jvm_static { 0x0008 } else { 0 };
    let mut method = simple_method(
        pool,
        flags,
        &function.name,
        &function.descriptor(),
        code,
        generic_function(function).as_deref(),
        !function.private && nonnull(&function.result),
    )?;
    if !function.private {
        parameter_annotations(pool, &mut method, &function.params)?;
    }
    if declaration.jvm_static {
        add_attribute(&mut method, jvm_static(pool)?)?;
    }
    if !declaration.throws.is_empty() {
        add_attribute(&mut method, exceptions(pool, &declaration.throws)?)?;
    }
    nullable_result(pool, &mut method, &function.result)?;
    frames::attach(
        pool,
        &mut method,
        owner,
        &function.params,
        function.locals,
        declaration.jvm_static,
    )?;
    Ok(method)
}

fn factory_name(field: &ObjectField) -> String {
    format!("{}$lambda$0", field.name)
}
fn accessor_name(field: &ObjectField) -> String {
    format!("access${}", factory_name(field))
}
fn supplier_name(owner: &str, field: &ObjectField) -> String {
    format!("{owner}${}$Supplier", field.name)
}

fn initializer_type(field: &ObjectField) -> &Type {
    match &field.initializer {
        ObjectInitializer::ThreadLocalArray { array_type, .. } => array_type,
        ObjectInitializer::Value { value, .. } => &value.ty,
    }
}

fn field(pool: &mut Pool, field: &ObjectField, access: u16) -> Result<Vec<u8>> {
    if matches!(field.initializer, ObjectInitializer::Value { .. }) {
        return class_field(
            pool,
            &field.name,
            &field.ty,
            0x0008 | access | if field.mutable { 0 } else { 0x0010 },
        );
    }
    let mut bytes = Vec::new();
    u2(&mut bytes, 0x001a);
    u2(&mut bytes, pool.utf8(&field.name)?);
    u2(&mut bytes, pool.utf8(&field.ty.descriptor())?);
    u2(&mut bytes, 1);
    u2(&mut bytes, pool.utf8("Signature")?);
    u4(&mut bytes, 2);
    u2(
        &mut bytes,
        pool.utf8(&format!(
            "Ljava/lang/ThreadLocal<{}>;",
            initializer_type(field).descriptor()
        ))?,
    );
    Ok(bytes)
}

fn factory(
    pool: &mut Pool,
    owner: &str,
    field: &ObjectField,
    lambdas: &[crate::check::LambdaDecl],
) -> Result<Vec<u8>> {
    let ObjectInitializer::ThreadLocalArray {
        array_type,
        size,
        locals,
    } = &field.initializer
    else {
        return Err(failure("Expected a ThreadLocal array initializer"));
    };
    let mut code = Code {
        pool,
        functions: &[],
        owner,
        bytes: Vec::new(),
        labels: Vec::new(),
        branches: Vec::new(),
        loops: Vec::new(),
        loop_finally_depths: Vec::new(),
        loop_names: Vec::new(),
        pending_loop_name: None,
        finalizers: Vec::new(),
        exceptions: Vec::new(),
        temporary_count: 0,
        temporary_patches: Vec::new(),
        lambdas,
        inline_local_maps: Vec::new(),
        inline_returns: Vec::new(),
        in_lambda: false,
        max_stack: 1,
    };
    code.value(size)?;
    code.bytes
        .extend([0xbc, primitive_array_type(array_type)?, 0xb0]);
    let max_stack =
        u16::try_from(code.max_stack).map_err(|_| failure("JVM operand stack limit exceeded"))?;
    let code = code.into_simple(*locals, max_stack)?;
    let mut method = simple_method(
        pool,
        0x001a,
        &factory_name(field),
        &format!("(){}", array_type.descriptor()),
        code,
        None,
        false,
    )?;
    frames::attach(pool, &mut method, owner, &[], *locals, true)?;
    Ok(method)
}

fn accessor(pool: &mut Pool, owner: &str, field: &ObjectField) -> Result<Vec<u8>> {
    let descriptor = format!("(){}", initializer_type(field).descriptor());
    let mut code = SimpleCode::new(1, 0);
    code.reference(0xb8, pool.method(owner, &factory_name(field), &descriptor)?);
    code.bytes.push(0xb0);
    simple_method(
        pool,
        0x1019,
        &accessor_name(field),
        &descriptor,
        code,
        None,
        false,
    )
}

fn supplier(owner: &str, field: &ObjectField, file: &str) -> Result<crate::ClassFile> {
    let name = supplier_name(owner, field);
    let mut builder = Builder::new(&name, 49, 0x1030, &["java/util/function/Supplier".into()])?;
    let mut signature = Vec::new();
    u2(&mut signature, builder.pool.utf8("Signature")?);
    u4(&mut signature, 2);
    u2(
        &mut signature,
        builder.pool.utf8(&format!(
            "Ljava/lang/Object;Ljava/util/function/Supplier<{}>;",
            initializer_type(field).descriptor()
        ))?,
    );
    builder.attributes.push(signature);
    let mut code = SimpleCode::new(1, 1);
    code.bytes.push(0x2a);
    code.reference(
        0xb7,
        builder.pool.method("java/lang/Object", "<init>", "()V")?,
    );
    code.bytes.push(0xb1);
    builder.methods.push(simple_method(
        &mut builder.pool,
        0,
        "<init>",
        "()V",
        code,
        None,
        false,
    )?);
    let mut code = SimpleCode::new(1, 1);
    code.reference(
        0xb8,
        builder.pool.method(
            owner,
            &accessor_name(field),
            &format!("(){}", initializer_type(field).descriptor()),
        )?,
    );
    code.bytes.push(0xb0);
    builder.methods.push(simple_method(
        &mut builder.pool,
        0x0011,
        "get",
        "()Ljava/lang/Object;",
        code,
        None,
        false,
    )?);
    builder.finish(
        file,
        &Metadata {
            kind: 3,
            data1: Vec::new(),
            data2: Vec::new(),
        },
        &[],
    )
}

pub fn emit_dynamic_object(
    object: &DynamicObject,
    owner: &str,
    file: &str,
    metadata: &Metadata,
    lambdas: &[crate::check::LambdaDecl],
) -> Result<Vec<crate::ClassFile>> {
    if object.owner != owner {
        return Err(failure("Object class identity mismatch"));
    }
    let mut builder = Builder::new(owner, 52, 0x0031, &object.interfaces)?;
    if object.serializable {
        builder
            .annotations
            .push("Lkotlinx/serialization/Serializable;".into());
        builder.field("$cachedSerializer$delegate", "Lkotlin/Lazy;", 0x101a, false)?;
        let mut signature = Vec::new();
        u2(&mut signature, builder.pool.utf8("Signature")?);
        u4(&mut signature, 2);
        u2(
            &mut signature,
            builder
                .pool
                .utf8("Lkotlin/Lazy<Lkotlinx/serialization/KSerializer<Ljava/lang/Object;>;>;")?,
        );
        let field = builder.fields.last_mut().unwrap();
        field[6..8].copy_from_slice(&1u16.to_be_bytes());
        field.extend(signature);
    }
    builder.field("INSTANCE", &format!("L{owner};"), 0x0019, true)?;
    for constant in &object.constants {
        builder
            .fields
            .push(constant_field(&mut builder.pool, constant)?);
    }
    for property in &object.fields {
        builder.fields.push(field(
            &mut builder.pool,
            property,
            object
                .exposed_fields
                .get(&property.name)
                .copied()
                .unwrap_or(0x0002),
        )?);
        if !lambdas.is_empty() {
            builder.methods.extend(field_bridges(
                &mut builder.pool,
                owner,
                &property.name,
                &property.ty,
                true,
                property.mutable,
            )?);
        }
    }
    let mut constructor = SimpleCode::new(1, 1);
    constructor.bytes.push(0x2a);
    constructor.reference(
        0xb7,
        builder.pool.method("java/lang/Object", "<init>", "()V")?,
    );
    constructor.bytes.push(0xb1);
    builder.methods.push(simple_method(
        &mut builder.pool,
        0x0002,
        "<init>",
        "()V",
        constructor,
        None,
        false,
    )?);
    if object.serializable {
        let mut getter = SimpleCode::new(1, 1);
        getter.reference(
            0xb2,
            builder
                .pool
                .field(owner, "$cachedSerializer$delegate", "Lkotlin/Lazy;")?,
        );
        getter.reference(
            0xb9,
            builder
                .pool
                .interface_method("kotlin/Lazy", "getValue", "()Ljava/lang/Object;")?,
        );
        getter.bytes.extend([1, 0]);
        getter.reference(
            0xc0,
            builder.pool.class("kotlinx/serialization/KSerializer")?,
        );
        getter.bytes.push(0xb0);
        builder.methods.push(simple_method(
            &mut builder.pool,
            0x1012,
            "get$cachedSerializer",
            "()Lkotlinx/serialization/KSerializer;",
            getter,
            None,
            false,
        )?);
        let mut code = SimpleCode::new(1, 1);
        code.bytes.push(0x2a);
        code.reference(
            0xb7,
            builder.pool.method(
                owner,
                "get$cachedSerializer",
                "()Lkotlinx/serialization/KSerializer;",
            )?,
        );
        code.bytes.push(0xb0);
        let signature = format!("()Lkotlinx/serialization/KSerializer<L{owner};>;");
        let mut method = simple_method(
            &mut builder.pool,
            0x0011,
            "serializer",
            "()Lkotlinx/serialization/KSerializer;",
            code,
            None,
            true,
        )?;
        let mut attribute = Vec::new();
        u2(&mut attribute, builder.pool.utf8("Signature")?);
        u4(&mut attribute, 2);
        u2(&mut attribute, builder.pool.utf8(&signature)?);
        add_attribute(&mut method, attribute)?;
        builder.methods.push(method);
    }
    for declaration in &object.methods {
        if !lambdas.is_empty() && declaration.function.private {
            builder.methods.push(private_method_bridge(
                &mut builder.pool,
                owner,
                &declaration.function,
                declaration.jvm_static,
            )?);
        }
        builder
            .methods
            .push(method(&mut builder.pool, owner, declaration, lambdas)?);
        if let Some(default) = defaults::function(
            &mut builder.pool,
            &[],
            &declaration.function,
            owner,
            declaration.jvm_static,
            lambdas,
        )? {
            builder.methods.push(default);
        }
    }
    for bridge in &object.bridges {
        builder
            .methods
            .push(interface_bridge(&mut builder.pool, bridge)?);
    }
    for property in &object.fields {
        if !matches!(
            property.initializer,
            ObjectInitializer::ThreadLocalArray { .. }
        ) {
            continue;
        }
        builder
            .methods
            .push(factory(&mut builder.pool, owner, property, lambdas)?);
    }
    for property in &object.fields {
        if !matches!(
            property.initializer,
            ObjectInitializer::ThreadLocalArray { .. }
        ) {
            continue;
        }
        builder
            .methods
            .push(accessor(&mut builder.pool, owner, property)?);
    }
    let mut initializer = SimpleCode::new(2, 0);
    initializer.reference(0xbb, builder.class);
    initializer.bytes.push(0x59);
    initializer.reference(0xb7, builder.pool.method(owner, "<init>", "()V")?);
    initializer.reference(
        0xb3,
        builder
            .pool
            .field(owner, "INSTANCE", &format!("L{owner};"))?,
    );
    if object.serializable {
        initializer.reference(
            0xb2,
            builder.pool.field(
                "kotlin/LazyThreadSafetyMode",
                "PUBLICATION",
                "Lkotlin/LazyThreadSafetyMode;",
            )?,
        );
        let supplier = format!("{owner}$SerializerSupplier");
        initializer.reference(
            0xb2,
            builder
                .pool
                .field(&supplier, "INSTANCE", &format!("L{supplier};"))?,
        );
        initializer.reference(
            0xb8,
            builder.pool.method(
                "kotlin/LazyKt",
                "lazy",
                "(Lkotlin/LazyThreadSafetyMode;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;",
            )?,
        );
        initializer.reference(
            0xb3,
            builder
                .pool
                .field(owner, "$cachedSerializer$delegate", "Lkotlin/Lazy;")?,
        );
    }
    for property in &object.fields {
        if !matches!(
            property.initializer,
            ObjectInitializer::ThreadLocalArray { .. }
        ) {
            continue;
        }
        let supplier = supplier_name(owner, property);
        initializer.reference(0xbb, builder.pool.class(&supplier)?);
        initializer.bytes.push(0x59);
        initializer.reference(0xb7, builder.pool.method(&supplier, "<init>", "()V")?);
        initializer.reference(
            0xb8,
            builder.pool.method(
                "java/lang/ThreadLocal",
                "withInitial",
                "(Ljava/util/function/Supplier;)Ljava/lang/ThreadLocal;",
            )?,
        );
        initializer.reference(
            0xb3,
            builder
                .pool
                .field(owner, &property.name, &property.ty.descriptor())?,
        );
    }
    let mut code = Code {
        pool: &mut builder.pool,
        functions: &[],
        owner,
        bytes: initializer.bytes,
        labels: Vec::new(),
        branches: Vec::new(),
        loops: Vec::new(),
        loop_finally_depths: Vec::new(),
        loop_names: Vec::new(),
        pending_loop_name: None,
        finalizers: Vec::new(),
        exceptions: Vec::new(),
        temporary_count: 0,
        temporary_patches: Vec::new(),
        lambdas,
        inline_local_maps: Vec::new(),
        inline_returns: Vec::new(),
        in_lambda: false,
        max_stack: 2,
    };
    let mut locals = object.locals;
    if object.initializers.is_empty() {
        for property in &object.fields {
            if let ObjectInitializer::Value {
                value,
                locals: field_locals,
            } = &property.initializer
            {
                locals = locals.max(*field_locals);
                code.value(value)?;
                code.field_reference(0xb3, owner, &property.name, &property.ty.descriptor())?;
            }
        }
    } else {
        code.block(&object.initializers)?;
    }
    code.bytes.push(0xb1);
    let max_stack = code.max_stack as u16;
    let initializer = code.into_simple(locals, max_stack)?;
    let mut initializer_method = simple_method(
        &mut builder.pool,
        0x0008,
        "<clinit>",
        "()V",
        initializer,
        None,
        false,
    )?;
    frames::attach(
        &mut builder.pool,
        &mut initializer_method,
        owner,
        &[],
        locals,
        true,
    )?;
    builder.methods.push(initializer_method);
    let mut classes = vec![builder.finish(file, metadata, &[])?];
    if object.serializable {
        classes.push(serializer_supplier(owner, file)?);
    }
    for property in &object.fields {
        if !matches!(
            property.initializer,
            ObjectInitializer::ThreadLocalArray { .. }
        ) {
            continue;
        }
        classes.push(supplier(owner, property, file)?);
    }
    Ok(classes)
}

fn serializer_supplier(owner: &str, file: &str) -> Result<crate::ClassFile> {
    let name = format!("{owner}$SerializerSupplier");
    let mut builder = Builder::new(
        &name,
        49,
        0x1030,
        &["kotlin/jvm/functions/Function0".into()],
    )?;
    builder.field("INSTANCE", &format!("L{name};"), 0x0018, false)?;
    let mut code = SimpleCode::new(1, 1);
    code.bytes.push(0x2a);
    code.reference(
        0xb7,
        builder.pool.method("java/lang/Object", "<init>", "()V")?,
    );
    code.bytes.push(0xb1);
    builder.methods.push(simple_method(
        &mut builder.pool,
        2,
        "<init>",
        "()V",
        code,
        None,
        false,
    )?);
    let mut code = SimpleCode::new(2, 0);
    code.reference(0xbb, builder.class);
    code.bytes.push(0x59);
    code.reference(0xb7, builder.pool.method(&name, "<init>", "()V")?);
    code.reference(
        0xb3,
        builder
            .pool
            .field(&name, "INSTANCE", &format!("L{name};"))?,
    );
    code.bytes.push(0xb1);
    builder.methods.push(simple_method(
        &mut builder.pool,
        8,
        "<clinit>",
        "()V",
        code,
        None,
        false,
    )?);
    let mut code = SimpleCode::new(5, 1);
    code.reference(
        0xbb,
        builder
            .pool
            .class("kotlinx/serialization/internal/ObjectSerializer")?,
    );
    code.bytes.push(0x59);
    code.reference(0x13, builder.pool.string(&owner.replace('/', "."))?);
    code.reference(
        0xb2,
        builder
            .pool
            .field(owner, "INSTANCE", &format!("L{owner};"))?,
    );
    code.bytes.push(0x03);
    code.reference(0xbd, builder.pool.class("java/lang/annotation/Annotation")?);
    code.reference(
        0xb7,
        builder.pool.method(
            "kotlinx/serialization/internal/ObjectSerializer",
            "<init>",
            "(Ljava/lang/String;Ljava/lang/Object;[Ljava/lang/annotation/Annotation;)V",
        )?,
    );
    code.bytes.push(0xb0);
    builder.methods.push(simple_method(
        &mut builder.pool,
        0x0011,
        "invoke",
        "()Ljava/lang/Object;",
        code,
        None,
        true,
    )?);
    builder.finish(
        file,
        &Metadata {
            kind: 3,
            data1: Vec::new(),
            data2: Vec::new(),
        },
        &[],
    )
}
