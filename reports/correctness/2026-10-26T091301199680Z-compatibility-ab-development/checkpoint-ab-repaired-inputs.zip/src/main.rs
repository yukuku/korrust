mod output;

use std::{env, fs, path::PathBuf, process::ExitCode};

fn run() -> std::result::Result<(), String> {
    let args: Vec<_> = env::args_os().skip(1).collect();
    if args.len() == 1 && args[0] == "--version" {
        println!("korrust {}", env!("CARGO_PKG_VERSION"));
        return Ok(());
    }
    let usage = "Usage: korrust [source.kt ...] -d <output-directory> [-cp <classpath>] [--module-name <name>]";
    let mut inputs = Vec::new();
    let mut module_name = None;
    let mut destination = None;
    let mut classpath = Vec::new();
    let mut index = 0;
    let mut has_classpath = false;
    while index < args.len() {
        if args[index] == "-d"
            || args[index] == "-cp"
            || args[index] == "--classpath"
            || args[index] == "--module-name"
        {
            let option = &args[index];
            index += 1;
            let value = args.get(index).ok_or(usage)?;
            if option == "-d" {
                if destination.is_some() {
                    return Err(usage.into());
                }
                destination = Some(PathBuf::from(value));
            } else if option == "--module-name" {
                if module_name.is_some() {
                    return Err(usage.into());
                }
                let name = value.to_str().ok_or("Invalid module name")?;
                if !output::valid_module_name(name) {
                    return Err(
                        "Invalid module name; expected 1–120 ASCII letters, digits, _, . or -"
                            .into(),
                    );
                }
                module_name = Some(name.to_owned());
            } else {
                if has_classpath || value.is_empty() {
                    return Err(usage.into());
                }
                has_classpath = true;
                classpath = env::split_paths(value).collect();
            }
        } else {
            if args[index].to_string_lossy().starts_with('-') {
                return Err(usage.into());
            }
            inputs.push(PathBuf::from(&args[index]));
        }
        index += 1;
    }
    let destination = destination.ok_or(usage)?;
    if inputs.is_empty() && module_name.is_none() {
        return Err(usage.into());
    }
    let batch = inputs.len() != 1 || module_name.is_some();
    let mut sources = Vec::new();
    let mut display_paths = std::collections::BTreeMap::new();
    for input in &inputs {
        let source = fs::read_to_string(input).map_err(|e| format!("{}: {e}", input.display()))?;
        let identity = fs::canonicalize(input).map_err(|e| format!("{}: {e}", input.display()))?;
        let identity = identity
            .to_str()
            .ok_or("Non-UTF-8 source paths are unsupported")?
            .to_owned();
        if display_paths.insert(identity.clone(), input).is_some() {
            return Err(format!("{}: Duplicate source identity", input.display()));
        }
        let file_name = input
            .file_name()
            .and_then(|s| s.to_str())
            .ok_or("Invalid source filename")?
            .to_owned();
        sources.push(korrust::SourceInput {
            identity,
            file_name,
            source,
        });
    }
    let paths = if batch {
        sources.sort_by(|left, right| left.identity.cmp(&right.identity));
        let name = module_name.as_deref().unwrap_or("main");
        let artifacts = korrust::compile_batch_with_classpath(&sources, &classpath, name).map_err(
            |diagnostic| {
                let source = diagnostic
                    .source_identity
                    .as_deref()
                    .and_then(|identity| sources.iter().find(|source| source.identity == identity))
                    .or_else(|| sources.first());
                match source {
                    Some(source) => diagnostic.render(
                        &display_paths[&source.identity].display().to_string(),
                        &source.source,
                    ),
                    None => diagnostic.render("<module>", ""),
                }
            },
        )?;
        output::write_module_outputs(name, &destination, artifacts)?
    } else {
        let source = &sources[0];
        let artifacts =
            korrust::compile_outputs_with_classpath(&source.source, &source.file_name, &classpath)
                .map_err(|e| e.render(&inputs[0].display().to_string(), &source.source))?;
        output::write_outputs(&inputs[0], &destination, artifacts)?
    };
    for path in paths {
        println!("{}", path.display());
    }
    Ok(())
}

fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(message) => {
            eprintln!("{message}");
            ExitCode::FAILURE
        }
    }
}
