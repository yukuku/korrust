fun value(): Any = InternalSignal
