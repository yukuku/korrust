fun result(): Int = four
const val eight = four * 2
fun folded(): Int = eight
fun objectValue(): Int = Marker.answer
fun objectField(): String = Marker.text
fun nullableField(): String? = Marker.absent
fun charset(): String = String(byteArrayOf(65, 66), Charsets.US_ASCII)
fun utf16Value(): String = utf16
fun local(four: Int): Int { val capture: () -> Int = { four }; return capture() }
fun objectShadow(Marker: Int): Int = Marker
class Scope(val four: Int) { fun result(): Int = four }
class Holder(val code: Int)
fun localQualifier(Signal: Holder): Int = Signal.code
fun captureQualifier(Signal: Holder): Int { val capture: () -> Int = { Signal.code }; return capture() }
fun defaultShadow(Charsets: Holder): Int = Charsets.code
