package near
import imported.selected
import imported.Signal
fun explicitValue(): Int = selected
fun explicitObject(): Int = Signal.code
