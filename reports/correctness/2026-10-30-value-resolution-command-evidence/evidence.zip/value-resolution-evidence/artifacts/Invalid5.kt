package missing
import imported.*
import other.*
fun value(): Int = Signal.code