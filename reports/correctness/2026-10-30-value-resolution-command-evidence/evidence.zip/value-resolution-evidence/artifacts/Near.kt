package near
const val selected = 17
object Signal { @JvmField val code: Int = 41 }
