package near
import near.selected as alternate
const val value = selected