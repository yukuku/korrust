public class Driver {
 public static void main(String[] args) {
  if (UseKt.result() != 4 || UseKt.folded() != 8 || UseKt.objectValue() != 19) throw new AssertionError("constants");
  if (!UseKt.objectField().equals("object-field") || UseKt.nullableField() != null || !UseKt.charset().equals("AB")) throw new AssertionError("object fields");
  String text = UseKt.utf16Value(); if (text.length() != 3 || text.charAt(1) != '\ud800') throw new AssertionError("UTF16");
  if (UseKt.local(53) != 53 || UseKt.objectShadow(59) != 59 || new Scope(61).result() != 61) throw new AssertionError("lexical shadowing");
  if (UseKt.localQualifier(new Holder(67)) != 67 || UseKt.captureQualifier(new Holder(71)) != 71 || UseKt.defaultShadow(new Holder(73)) != 73) throw new AssertionError("qualifier shadowing");
  if (near.PriorityKt.explicitValue() != 23 || near.PriorityKt.explicitObject() != 43) throw new AssertionError("explicit imports");
  if (near.StarKt.samePackage() != 17 || near.StarKt.sameObject() != 41) throw new AssertionError("same package");
  if (near.AliasKt.renamed() != 23 || near.AliasKt.original() != 17 || near.AliasKt.objectRenamed() != 43 || named.DefaultImportKt.defaultPackageImport() != 4) throw new AssertionError("renamed imports");
  System.out.println("value-resolution-ok");
 }
}