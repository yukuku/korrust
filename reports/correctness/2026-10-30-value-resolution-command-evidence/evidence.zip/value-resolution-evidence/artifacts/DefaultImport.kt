package named
import four as count
fun defaultPackageImport(): Int = count
