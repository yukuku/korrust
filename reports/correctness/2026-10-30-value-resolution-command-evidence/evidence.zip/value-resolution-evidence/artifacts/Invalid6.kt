package near
import near.selected as alternate
fun value(): Int = selected