package near
import imported.*
fun samePackage(): Int = selected
fun sameObject(): Int = Signal.code
