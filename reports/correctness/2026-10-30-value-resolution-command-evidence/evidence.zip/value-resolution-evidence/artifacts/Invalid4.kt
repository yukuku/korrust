package missing
import imported.*
import other.*
fun value(): Int = clash