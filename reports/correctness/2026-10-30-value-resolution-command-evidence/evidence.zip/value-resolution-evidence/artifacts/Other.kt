package other
const val selected = 31
const val clash = 2
object Signal { @JvmField val code: Int = 47 }
