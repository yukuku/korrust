fun main() { check(folded() == 8); check(eight == 8); check(Scope(four = 5).result() == 5); check(near.explicitValue() == 23) }
