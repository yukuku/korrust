fun value(): Int = internalCount
const val sum = internalCount + 1
