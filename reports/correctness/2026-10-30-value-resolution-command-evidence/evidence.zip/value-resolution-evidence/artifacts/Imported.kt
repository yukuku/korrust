package imported
const val selected = 23
const val clash = 1
object Signal { @JvmField val code: Int = 43 }
