package near
import imported.selected as alternate
import imported.Signal as OtherSignal
fun renamed(): Int = alternate
fun original(): Int = selected
fun objectRenamed(): Int = OtherSignal.code
