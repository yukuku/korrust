const val four = 2 + 2
internal const val internalCount = 7
internal object InternalSignal { @JvmField val code: Int = 79 }
private const val privateCount = 8
const val utf16 = "a\ud800b"
object Marker { const val answer = 19; @JvmField val text: String = "object-field"; @JvmField val absent: String? = null }
