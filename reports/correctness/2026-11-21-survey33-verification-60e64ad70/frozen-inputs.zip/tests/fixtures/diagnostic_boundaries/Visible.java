public class Visible {}
