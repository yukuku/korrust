use super::*;

fn literal(expression: &Expr) -> bool {
    match &expression.kind {
        ExprKind::Int(_)
        | ExprKind::Long(_)
        | ExprKind::Float(_)
        | ExprKind::Double(_)
        | ExprKind::Char(_)
        | ExprKind::Boolean(_)
        | ExprKind::String(_) => true,
        ExprKind::Unary(_, value) | ExprKind::AnnotationConstant { value, .. } => literal(value),
        ExprKind::Binary(_, left, right) => literal(left) && literal(right),
        ExprKind::AnnotationArray(values) | ExprKind::Template(values) => {
            values.iter().all(literal)
        }
        _ => false,
    }
}

pub(super) fn validate(source: &syntax::Module, classpath: &Classpath, scope: &str) -> Result<()> {
    if source.local_annotations.is_empty() {
        return Ok(());
    }
    let mut imports = crate::annotation_declarations::imports(source, classpath)?;
    for (annotations, target) in &source.local_annotations {
        for annotation in annotations {
            if !annotation.name.contains('/')
                && let Some(crate::classpath::ValueSymbol::Classifier(class)) =
                    classpath.value_symbol(scope, &annotation.name, annotation.offset)?
            {
                imports.insert(annotation.name.clone(), class.name);
            }
        }
        let emitted = annotations::declaration_annotations(
            annotations,
            classpath,
            &imports,
            target,
            None,
            Some(scope),
        )?;
        if !emitted.is_empty() {
            return Err(Diagnostic::new(
                annotations[0].offset,
                "Nonsource local and expression annotation retention is unsupported",
            )
            .with_kind(
                crate::DiagnosticKind::UnsupportedLanguage,
                "LOCAL_ANNOTATION_RETENTION_UNSUPPORTED",
            ));
        }
        for annotation in annotations {
            if annotation
                .arguments
                .iter()
                .any(|(_, value)| !literal(value))
            {
                return Err(Diagnostic::new(
                    annotation.offset,
                    "Local annotation arguments currently require literal constant expressions",
                )
                .with_kind(
                    crate::DiagnosticKind::UnsupportedLanguage,
                    "LOCAL_ANNOTATION_ARGUMENT_CONTEXT_UNSUPPORTED",
                ));
            }
            if annotations::annotation_owner(&annotation.name, classpath, &imports)
                != "kotlin/Suppress"
            {
                continue;
            }
            let checked = crate::annotation_declarations::checked_use(
                annotation,
                classpath,
                &imports,
                Some(scope),
            )?;
            for (_, value) in &checked.values {
                let DeclarationAnnotationValue::Array(values) = value else {
                    return Err(Diagnostic::new(
                        annotation.offset,
                        "Suppress requires String names",
                    )
                    .with_kind(
                        crate::DiagnosticKind::InvalidKotlin,
                        "SUPPRESS_ARGUMENT_INVALID",
                    ));
                };
                for value in values {
                    let DeclarationAnnotationValue::String(units) = value else {
                        return Err(Diagnostic::new(
                            annotation.offset,
                            "Suppress requires String names",
                        )
                        .with_kind(
                            crate::DiagnosticKind::InvalidKotlin,
                            "SUPPRESS_ARGUMENT_INVALID",
                        ));
                    };
                    let name = String::from_utf16_lossy(units);
                    if !matches!(name.as_str(), "UNCHECKED_CAST" | "RestrictedApi") {
                        return Err(Diagnostic::new(
                            annotation.offset,
                            format!("Local suppression {name} may require unsupported diagnostic semantics"),
                        )
                        .with_kind(
                            crate::DiagnosticKind::UnsupportedLanguage,
                            "SUPPRESSION_DIAGNOSTIC_UNSUPPORTED",
                        ));
                    }
                }
            }
        }
    }
    Ok(())
}
