#!/usr/bin/env python3
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile
from upstream_jvm import Commands, normalize_signature, run_case, publish_report

ROOT = Path(__file__).resolve().parents[1]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--publish', type=Path)
    args = parser.parse_args()
    work = args.output.resolve()
    work.mkdir(parents=True)
    commands_dir = work / 'commands'
    commands_dir.mkdir()
    commands = Commands(commands_dir, dict(os.environ))
    jdk = Path(os.environ['JAVA_HOME']) / 'bin'
    lib = ROOT / 'references/kotlinc/lib'
    standard = lib / 'kotlin-stdlib.jar'
    compiler = args.candidate.resolve()
    oracle = ROOT / 'references/kotlinc/bin/kotlinc'
    fixtures = ROOT / 'tests/expanded_objects'
    report = {'schema_version': 1, 'kind': 'correctness', 'created_at': datetime.now(timezone.utc).isoformat(), 'status': 'running', 'cases': [], 'commands': commands.entries, 'compiler': {'path': str(compiler), 'sha256': sha(compiler)}, 'reference_compiler': {'version': '2.3.21', 'compiler_jar_sha256': sha(lib / 'kotlin-compiler.jar'), 'stdlib_sha256': sha(standard)}, 'environment': {'JAVA_HOME': os.environ['JAVA_HOME']}, 'claims': 'Bounded data-object singleton semantics and nested interface supertypes; not full reflection or unrestricted object inheritance.'}
    files = sorted([p for directory in ['src', 'tests/expanded_objects'] for p in (ROOT / directory).rglob('*') if p.is_file()] + [Path(__file__), ROOT / 'tools/upstream_jvm.py', ROOT / 'Cargo.toml', ROOT / 'Cargo.lock'])
    frozen = {str(p.relative_to(ROOT)): sha(p) for p in files}
    (work / 'source-manifest.json').write_text(json.dumps(frozen, indent=2))
    with zipfile.ZipFile(work / 'source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, str(path.relative_to(ROOT)))
    def cp(*paths):
        return os.pathsep.join(map(str, paths))
    def run(label, argv):
        result = commands.run(label, argv)
        if result is None or result.returncode:
            raise RuntimeError(label + ': ' + (result.stderr if result else 'timeout'))
        return result
    def case(name, **values):
        report['cases'].append({'id': name, 'outcome': 'pass', **values})
    try:
        destinations = {}
        for provider in ['official', 'candidate']:
            dest = work / provider
            argv = [oracle if provider == 'official' else compiler, fixtures / 'Objects.kt', '-cp', standard, '-d', dest]
            argv += ['-jvm-target', '1.8', '-language-version', '2.3', '-api-version', '2.3'] if provider == 'official' else ['--diagnostic-format', 'json']
            run('Compile ' + provider, argv)
            destinations[provider] = dest
            case('compile/' + provider)
        java = work / 'java'
        run('Compile fixed Java caller', [jdk / 'javac', '-cp', cp(destinations['official'], standard), '-d', java, fixtures / 'Check.java'])
        for provider, dest in destinations.items():
            output = run('Execute fixed caller ' + provider, [jdk / 'java', '-Xverify:all', '-cp', cp(java, dest, standard), 'Check']).stdout.strip()
            if not output.startswith('OK '):
                raise RuntimeError(output)
            case('runtime/' + provider, independent_assertions=int(output.split()[1]), output=output)
        metadata = work / 'metadata'
        run('Compile metadata reader', [jdk / 'javac', '-cp', cp(standard, lib / 'kotlin-compiler.jar'), '-d', metadata, fixtures / 'MetadataDump.java'])
        owners = ['objectcases.Start', 'objectcases.Stop', 'objectcases.Container$Nested', 'objectcases.Empty', 'objectcases.Tracked']
        outputs = {}
        for provider, dest in destinations.items():
            outputs[provider] = sorted(run('Read metadata ' + provider, [jdk / 'java', '-Xverify:all', '-cp', cp(metadata, dest, standard, lib / 'kotlin-compiler.jar'), 'MetadataDump', *owners]).stdout.splitlines())
        if outputs['official'] != outputs['candidate']:
            raise RuntimeError('Metadata mismatch: ' + repr(outputs))
        case('metadata', snapshots=outputs)
        for owner in owners + ['objectcases.ObjectsKt']:
            signatures = {provider: normalize_signature(run('Signature ' + provider + '/' + owner, [jdk / 'javap', '-p', '-s', '-classpath', dest, owner]).stdout) for provider, dest in destinations.items()}
            if signatures['official'] != signatures['candidate']:
                raise RuntimeError('Signature mismatch ' + owner + repr(signatures))
            case('signature/' + owner)
        for provider, dest in destinations.items():
            consumer = work / ('consumer-' + provider)
            run('Compile Kotlin consumer ' + provider, [oracle, fixtures / 'Consumer.kt', '-cp', cp(dest, standard), '-d', consumer, '-jvm-target', '1.8', '-language-version', '2.3', '-api-version', '2.3'])
            launcher = work / ('launcher-' + provider)
            run('Compile Kotlin consumer launcher ' + provider, [jdk / 'javac', '-cp', cp(consumer, standard), '-d', launcher, fixtures / 'Launch.java'])
            output = run('Execute Kotlin consumer ' + provider, [jdk / 'java', '-Xverify:all', '-cp', cp(launcher, consumer, dest, standard), 'Launch']).stdout.strip()
            if output != 'OK':
                raise RuntimeError(output)
            case('kotlin_consumer/' + provider)
        context = {'directory': work / 'upstream', 'commands': commands, 'candidate': compiler, 'official': oracle, 'stdlib': standard, 'testlib': lib / 'kotlin-test.jar', **{name: str(jdk / name) for name in ['java', 'javac', 'javap']}}
        for name in ['equals', 'hashCode', 'toString', 'multipleInstances']:
            path = ROOT / 'references/kotlin/compiler/testData/codegen/box/dataObjects' / (name + '.kt')
            entry = {'id': 'upstream/' + name, 'family': 'expanded_objects', 'root': 'box', 'path': str(path.relative_to(ROOT)), 'kind': 'box', 'sha256': sha(path)}
            report['cases'].append(run_case(entry, context))
        report['status'] = 'complete'
    except Exception as error:
        report['status'] = 'failed'
        report['failure'] = str(error)
    report['input_integrity'] = {'changed_paths': [name for name, expected in frozen.items() if sha(ROOT / name) != expected]}
    report['counts'] = dict(Counter(case['outcome'] for case in report['cases']))
    (work / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    if args.publish:
        publish_report(report, work, args.publish.resolve())
    print(json.dumps({'status': report['status'], 'counts': report['counts'], 'failure': report.get('failure')}))
    return 0 if report['status'] == 'complete' else 1

if __name__ == '__main__':
    raise SystemExit(main())
