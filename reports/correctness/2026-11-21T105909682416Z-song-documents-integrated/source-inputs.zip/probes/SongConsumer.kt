package songconsumer
import yuku.alkitab.songs.newdoc.*
fun main() {
    val document = SongDocument("0", Meta(null, null), emptyList())
    check(SongDocumentSearch.searchableTexts(document) == listOf("0"))
    check(SongDocumentSearch.lyricLines(document).isEmpty())
    check(SongDocumentText.render(document, null, null, { index -> "Version $index" }, "R") == "0. \n\n\n\n")
    println("OK")
}
