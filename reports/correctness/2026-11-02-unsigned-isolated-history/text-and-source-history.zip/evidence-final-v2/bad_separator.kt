fun f() = 1_u
