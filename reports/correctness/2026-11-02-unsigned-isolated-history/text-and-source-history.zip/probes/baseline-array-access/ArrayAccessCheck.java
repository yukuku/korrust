public class ArrayAccessCheck {
    public static void main(String[] args) { System.out.println(importedscalar.ArrayImportKt.kind()); }
}
