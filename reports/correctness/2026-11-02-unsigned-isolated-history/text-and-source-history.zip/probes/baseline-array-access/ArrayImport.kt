package importedscalar
import externalvalue.ArrayCounter
fun kind(): Class<*> = ArrayCounter(0).arrayKind()
