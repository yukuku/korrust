from pathlib import Path
import shutil,struct
root=Path('target/resume-unsigned/probes')
shutil.copytree(root/'array-dependency',root/'array-inaccessible',dirs_exist_ok=True)
p=root/'array-inaccessible/externalvalue/ProbeToken.class';data=bytearray(p.read_bytes());count=struct.unpack_from('>H',data,8)[0];cursor=10;index=1
while index<count:
 tag=data[cursor];cursor+=1
 if tag==1:
  size=struct.unpack_from('>H',data,cursor)[0];cursor+=2+size
 elif tag in [3,4,9,10,11,12,17,18]:cursor+=4
 elif tag in [5,6]:cursor+=8;index+=1
 elif tag in [7,8,16,19,20]:cursor+=2
 elif tag==15:cursor+=3
 else:raise ValueError(tag)
 index+=1
flags=struct.unpack_from('>H',data,cursor)[0];struct.pack_into('>H',data,cursor,flags&~1);p.write_bytes(data)
