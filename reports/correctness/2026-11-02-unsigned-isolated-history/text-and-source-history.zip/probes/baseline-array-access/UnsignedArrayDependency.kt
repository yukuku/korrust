@file:Suppress("INVISIBLE_REFERENCE", "INVISIBLE_MEMBER")
package externalvalue
class ProbeToken
@JvmInline
value class ArrayCounter(val raw: Int) {
    @kotlin.internal.InlineOnly
    inline fun arrayKind(): Class<*> = Array<ProbeToken>::class.java
}
