package newfamilies.dependency;

public final class InitializationProbe {
    static { InitializationTrace.initializations++; }
    public static InitializationProbe create() {
        InitializationTrace.creations++;
        return new InitializationProbe();
    }
}
