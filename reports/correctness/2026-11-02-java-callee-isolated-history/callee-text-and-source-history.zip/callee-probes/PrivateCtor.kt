package callee
fun f() = Arena.PrivateCtor()
