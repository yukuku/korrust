package callee
fun f() = Arena.StringCtor("x")
