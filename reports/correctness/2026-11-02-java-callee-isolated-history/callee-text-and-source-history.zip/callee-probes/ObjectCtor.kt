package callee
fun f() = Arena.ObjectCtor("x")
