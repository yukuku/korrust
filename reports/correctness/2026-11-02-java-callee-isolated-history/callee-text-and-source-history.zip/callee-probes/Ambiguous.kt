package callee
fun f() = Arena.Ambiguous()
