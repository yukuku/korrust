package callee
fun f() = Arena.AbstractCtor()
