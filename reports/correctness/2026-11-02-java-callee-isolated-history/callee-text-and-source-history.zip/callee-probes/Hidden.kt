package callee
fun f() = Arena.Hidden()
