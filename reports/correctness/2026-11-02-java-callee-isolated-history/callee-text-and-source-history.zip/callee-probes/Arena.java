package callee;
public class Arena {
    public static class Ambiguous { public Ambiguous() {} }
    public static String Ambiguous() { return "method"; }
    public static class CtorOnly { public CtorOnly() {} }
    public static String CtorOnly(int value) { return "method"; }
    public static class MethodOnly { public MethodOnly(int value) {} }
    public static String MethodOnly() { return "method"; }
    public static class StringCtor { public StringCtor(String value) {} }
    public static String StringCtor(Object value) { return "method"; }
    public static class ObjectCtor { public ObjectCtor(Object value) {} }
    public static String ObjectCtor(String value) { return "method"; }
    public static class PrivateCtor { private PrivateCtor() {} }
    public static String PrivateCtor() { return "method"; }
    public static abstract class AbstractCtor { public AbstractCtor() {} }
    public static String AbstractCtor() { return "method"; }
    public class InnerCtor { public InnerCtor() {} }
    public static String InnerCtor() { return "method"; }
    private static class Hidden { public Hidden() {} }
    public static String Hidden() { return "method"; }
}
