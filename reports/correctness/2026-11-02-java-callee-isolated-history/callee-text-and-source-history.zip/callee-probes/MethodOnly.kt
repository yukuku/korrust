package callee
fun f() = Arena.MethodOnly()
