package callee
fun f() = Arena.CtorOnly()
