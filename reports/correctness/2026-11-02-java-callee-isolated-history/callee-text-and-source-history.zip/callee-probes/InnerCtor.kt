package callee
fun f() = Arena.InnerCtor()
