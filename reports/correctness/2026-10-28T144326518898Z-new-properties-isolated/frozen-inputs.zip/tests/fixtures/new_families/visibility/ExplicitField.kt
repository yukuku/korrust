package visibilityexplicit
import visibilityprobe.FakeCompanion
fun write(value: Int): Int { FakeCompanion.Companion.value = value; return FakeCompanion.Companion.value }
