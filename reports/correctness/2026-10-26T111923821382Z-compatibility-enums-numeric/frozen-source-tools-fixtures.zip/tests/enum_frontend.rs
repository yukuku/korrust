use korrust::{SourceInput, compile_all_with_classpath, compile_batch_with_classpath};
use std::path::PathBuf;

fn standard() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("references/kotlinc/lib/kotlin-stdlib.jar")
}

#[test]
fn enum_constructors_members_and_companions_use_ordinary_types() {
    let standard = standard();
    if !standard.is_file() {
        return;
    }
    let source = include_str!("fixtures/compatibility_enums_numeric/EnumModel.kt");
    let outputs = compile_all_with_classpath(source, "EnumModel.kt", &[standard]).unwrap();
    for owner in [
        "compatibility/enumsnumeric/Signal",
        "compatibility/enumsnumeric/Signal$Companion",
        "compatibility/enumsnumeric/Empty",
    ] {
        assert!(
            outputs.iter().any(|class| class.internal_name == owner),
            "{owner}"
        );
    }
}

#[test]
fn enum_initialization_dependencies_and_argument_types_reject_at_original_source() {
    let standard = standard();
    if !standard.is_file() {
        return;
    }
    for source in [
        "enum class E(val number: Int) { A(\"wrong\") }",
        "enum class E(val number: Int) { A(1); companion object { fun bad(): E = E(2) } }",
        "enum class E(val number: Int) { A(1) }\nfun bad(): E = E(2)",
        "enum class E(val number: Int) { A(B.number), B(2) }",
        "enum class E(val number: Int) { A(if(true) E.B.number else 0), B(2) }",
        "enum class E(val number: Int) { A(next()); companion object { fun next(): Int = 1 } }",
        "enum class E(val number: Int) { A(E.next()); companion object { fun next(): Int = 1 } }",
    ] {
        let input = SourceInput {
            identity: "/original/Enum.kt".into(),
            file_name: "Enum.kt".into(),
            source: source.into(),
        };
        let error =
            compile_batch_with_classpath(&[input], std::slice::from_ref(&standard), "enum_fixture")
                .err().expect("Invalid enum must reject");
        assert_eq!(error.source_identity.as_deref(), Some("/original/Enum.kt"));
        assert!(
            !error.message.to_lowercase().contains("unsupported"),
            "{}",
            error.message
        );
        assert!(error.offset > 0, "{}", error.message);
    }
}
