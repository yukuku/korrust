use super::*;

pub(crate) struct CheckedEnum {
    pub class: ClassDecl,
    pub entries: Vec<(String, Value)>,
    pub initializer_locals: u16,
    pub lambdas: Vec<LambdaDecl>,
}

/// Check enum user declarations with the ordinary class/expression machinery.
/// The two JVM-only constructor parameters are inserted before checking so all
/// constructor slots, default expressions, and initialized properties agree.
pub(crate) fn check_enum(
    module: &syntax::Module,
    classpath: &Classpath,
    owner: &str,
) -> Result<CheckedEnum> {
    let source = module
        .enum_decl
        .as_ref()
        .ok_or_else(|| Diagnostic::new(0, "Missing enum declaration"))?;
    if source.entries.len() > 1024 {
        return Err(Diagnostic::new(
            source.offset,
            "Enum exceeds the current 1024-entry limit",
        ));
    }
    if source.entries.len() != source.entry_arguments.len() {
        return Err(Diagnostic::new(
            source.offset,
            "Enum entry arguments are inconsistent",
        ));
    }
    let mut imports = module
        .imports
        .iter()
        .filter(|(alias, _, _)| alias != "*")
        .map(|(alias, path, _)| (alias.clone(), path.clone()))
        .collect::<HashMap<_, _>>();
    let mut classes = HashMap::new();
    for (alias, path, _) in &module.imports {
        if alias == "*" {
            for class in classpath.package_classes(path.trim_end_matches("/*"))? {
                imports
                    .entry(class.name.rsplit('/').next().unwrap().into())
                    .or_insert_with(|| class.name.clone());
                classes.insert(class.name.clone(), class);
            }
        } else if let Ok(class) = classpath.load(path) {
            classes.insert(path.clone(), class);
        } else if let Some((package, name)) = path.rsplit_once('/') {
            for class in classpath.package_classes(package)? {
                if class.methods.iter().any(|method| {
                    method
                        .library
                        .as_ref()
                        .is_some_and(|library| library.source_name == name)
                        || method.source_property.as_deref() == Some(name)
                }) {
                    imports.insert(alias.clone(), format!("{}::{name}", class.name));
                    classes.insert(class.name.clone(), class);
                }
            }
        }
    }
    imports.insert(source.name.clone(), owner.into());
    classes.insert(owner.into(), classpath.load(owner)?);
    for (entry, _) in &source.entries {
        imports.insert(entry.clone(), format!("{owner}::{entry}"));
    }
    imports.insert("entries".into(), format!("{owner}::entries"));
    let mut body = source.body.clone();
    body.params.splice(
        0..0,
        [
            ("<enum-name>".into(), Type::String),
            ("<enum-ordinal>".into(), Type::Int),
        ],
    );
    body.defaults.splice(0..0, [None, None]);
    body.param_annotations
        .splice(0..0, [Vec::new(), Vec::new()]);
    body.super_class = Some((
        "java/lang/Enum".into(),
        vec![
            Expr {
                offset: source.offset,
                kind: ExprKind::Name("<enum-name>".into()),
            },
            Expr {
                offset: source.offset,
                kind: ExprKind::Name("<enum-ordinal>".into()),
            },
        ],
    ));
    let lambdas = Rc::new(RefCell::new(Vec::new()));
    let mut class = declarations::check_class(
        &body,
        &module.package,
        classpath,
        &imports,
        &classes,
        &HashMap::new(),
        Some(owner),
        &lambdas,
    )?;
    let generated_methods = [
        ("values", format!("()[L{owner};")),
        ("valueOf", format!("(Ljava/lang/String;)L{owner};")),
        ("getEntries", "()Lkotlin/enums/EnumEntries;".into()),
        ("$values", format!("()[L{owner};")),
    ];
    for function in &class.methods {
        if generated_methods.iter().any(|(name, descriptor)| {
            function.name == *name && function.descriptor() == *descriptor
        }) {
            return Err(Diagnostic::new(
                source.offset,
                format!(
                    "Enum member conflicts with generated JVM method: {}",
                    function.name
                ),
            ));
        }
    }
    for field in &class.fields {
        if source.entries.iter().any(|(name, _)| *name == field.name)
            || matches!(field.name.as_str(), "$VALUES" | "$ENTRIES")
        {
            return Err(Diagnostic::new(
                source.offset,
                format!(
                    "Enum property conflicts with generated field: {}",
                    field.name
                ),
            ));
        }
    }
    class.super_class = "java/lang/Enum".into();
    class.super_args = vec![
        Value {
            ty: Type::String,
            kind: ValueKind::Local(1),
        },
        Value {
            ty: Type::Int,
            kind: ValueKind::Local(2),
        },
    ];
    let companion_names = source
        .body
        .companion
        .as_ref()
        .map(|companion| {
            companion
                .methods
                .iter()
                .map(|method| method.function.name.clone())
                .chain(
                    companion
                        .properties
                        .iter()
                        .map(|property| property.name.clone()),
                )
                .chain(std::iter::once("Companion".into()))
                .collect::<HashSet<_>>()
        })
        .unwrap_or_default();
    let context =
        declarations::DeclarationContext::new(owner, classpath, &imports, &classes, &lambdas);
    let mut entries = Vec::new();
    let mut initializer_locals = 0;
    for (ordinal, ((name, offset), arguments)) in source
        .entries
        .iter()
        .zip(&source.entry_arguments)
        .enumerate()
    {
        let uninitialized = source.entries[ordinal..]
            .iter()
            .map(|(name, _)| name.clone())
            .chain(companion_names.iter().cloned())
            .collect::<HashSet<_>>();
        for argument in arguments {
            let names = captures::free_names(
                &[syntax::Statement {
                    offset: argument.offset,
                    kind: syntax::StatementKind::Expression(argument.clone()),
                }],
                &[],
            );
            if let Some(name) = names.iter().find(|name| uninitialized.contains(*name)) {
                return Err(Diagnostic::new(
                    argument.offset,
                    format!("Enum declaration {name} is uninitialized in this entry argument"),
                ));
            }
            if let Some(name) = qualified_dependency(argument, &source.name, &uninitialized) {
                return Err(Diagnostic::new(
                    argument.offset,
                    format!("Enum declaration {name} is uninitialized in this entry argument"),
                ));
            }
        }
        let mut arguments = arguments.clone();
        arguments.splice(
            0..0,
            [
                Expr {
                    offset: *offset,
                    kind: ExprKind::String(name.encode_utf16().collect()),
                },
                Expr {
                    offset: *offset,
                    kind: ExprKind::Int(ordinal as i64),
                },
            ],
        );
        let mut checker = context.checker(false, 0, Type::Unit);
        checker.allow_return = false;
        let value = checker.construct_value(
            owner,
            &class.params,
            &vec![false; class.params.len()],
            &arguments,
            true,
            *offset,
        )?;
        initializer_locals = initializer_locals.max(checker.next);
        entries.push((name.clone(), value));
    }
    drop(context);
    Ok(CheckedEnum {
        class,
        entries,
        initializer_locals,
        lambdas: Rc::try_unwrap(lambdas).ok().unwrap().into_inner(),
    })
}

fn qualified_dependency<'a>(
    expr: &'a Expr,
    enum_name: &str,
    unavailable: &HashSet<String>,
) -> Option<&'a str> {
    match &expr.kind {
        ExprKind::Property(target, name) | ExprKind::SafeProperty(target, name) => {
            if matches!(&target.kind, ExprKind::Name(owner) if owner == enum_name)
                && unavailable.contains(name)
            {
                Some(name)
            } else {
                qualified_dependency(target, enum_name, unavailable)
            }
        }
        ExprKind::Call(target, arguments) => qualified_dependency(target, enum_name, unavailable)
            .or_else(|| {
                arguments
                    .iter()
                    .find_map(|argument| qualified_dependency(argument, enum_name, unavailable))
            }),
        ExprKind::Generic(value, _)
        | ExprKind::NamedArgument(_, value)
        | ExprKind::Unary(_, value)
        | ExprKind::NonNull(value)
        | ExprKind::TypeOperation(_, value, _)
        | ExprKind::Labeled(_, value) => qualified_dependency(value, enum_name, unavailable),
        ExprKind::Binary(_, left, right) | ExprKind::Index(left, right) => {
            qualified_dependency(left, enum_name, unavailable)
                .or_else(|| qualified_dependency(right, enum_name, unavailable))
        }
        ExprKind::If(condition, yes, no) => [condition.as_ref(), yes.as_ref(), no.as_ref()]
            .into_iter()
            .find_map(|value| qualified_dependency(value, enum_name, unavailable)),
        ExprKind::Template(parts) => parts
            .iter()
            .find_map(|value| qualified_dependency(value, enum_name, unavailable)),
        _ => None,
    }
}

/// Kotlin's predeclared Enum properties map to Enum.name()/ordinal() on JVM.
/// Apply this language mapping only to actual enum declarations; ordinary Java
/// methods with these names retain ordinary function-call semantics.
pub(super) fn property(checker: &mut Checker<'_>, receiver: &Value, name: &str, offset: usize) -> Result<Option<Value>> {
    let (descriptor, result) = match name {
        "name" => ("()Ljava/lang/String;", Type::String),
        "ordinal" => ("()I", Type::Int),
        _ => return Ok(None),
    };
    let Some(owner) = library::type_owner(&receiver.ty) else { return Ok(None); };
    if !checker.classpath.load(owner).is_ok_and(|class| class.access & 0x4000 != 0) {
        return Ok(None);
    }
    let mut method = checker.classpath.methods("java/lang/Enum")?.into_iter()
        .find(|method| method.name == name && method.descriptor == descriptor)
        .ok_or_else(|| Diagnostic::new(offset, "Missing JVM Enum property method"))?;
    method.kotlin_params = Some(Vec::new());
    method.kotlin_result = Some(result);
    checker.member_call(method, receiver.clone(), &[], offset).map(Some)
}
