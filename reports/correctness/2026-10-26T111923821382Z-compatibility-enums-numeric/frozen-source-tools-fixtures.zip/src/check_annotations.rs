use super::*;
use crate::classpath::AnnotationRetention;

pub(super) fn declaration_annotations(
    annotations: &[syntax::AnnotationUse],
    classpath: &Classpath,
    imports: &HashMap<String, String>,
    target: &str,
    use_site: Option<&str>,
) -> Result<Vec<DeclarationAnnotation>> {
    let mut result = Vec::new();
    let mut seen = HashSet::new();
    for annotation in annotations {
        if annotation.use_site.as_deref() != use_site {
            return Err(Diagnostic::new(
                annotation.offset,
                "Annotation use-site target is not valid for this declaration",
            ));
        }
        let owner = imports
            .get(&annotation.name)
            .cloned()
            .unwrap_or_else(|| annotation.name.clone());
        if matches!(
            owner.as_str(),
            "kotlinx/serialization/Serializable" | "androidx/compose/runtime/Composable"
        ) {
            return Err(Diagnostic::new(
                annotation.offset,
                format!(
                    "Annotation {} requires unsupported compiler plugin transformations",
                    annotation.name
                ),
            ));
        }
        let class = classpath.load(&owner).map_err(|mut error| {
            error.offset = annotation.offset;
            error
        })?;
        let definition = class.annotation_definition.ok_or_else(|| {
            Diagnostic::new(
                annotation.offset,
                format!("Unsupported annotation definition: {}", annotation.name),
            )
        })?;
        if !definition.targets.iter().any(|allowed| allowed == target) {
            return Err(Diagnostic::new(
                annotation.offset,
                format!("Annotation {} cannot target {target}", annotation.name),
            ));
        }
        if !seen.insert(owner.clone()) {
            return Err(Diagnostic::new(
                annotation.offset,
                "Repeated annotations require a repeatable declaration",
            ));
        }
        let mut supplied = HashSet::new();
        let mut values = Vec::new();
        for (position, (name, expression)) in annotation.arguments.iter().enumerate() {
            let name = match name {
                Some(name) => name.as_str(),
                None if position == 0 => "value",
                None => {
                    return Err(Diagnostic::new(
                        expression.offset,
                        "Java annotation arguments after value must be named",
                    ));
                }
            };
            let (_, descriptor, _) = definition
                .parameters
                .iter()
                .find(|(parameter, _, _)| parameter == name)
                .ok_or_else(|| {
                    Diagnostic::new(
                        expression.offset,
                        format!("Unknown annotation argument: {name}"),
                    )
                })?;
            if !supplied.insert(name.to_owned()) {
                return Err(Diagnostic::new(
                    expression.offset,
                    "Duplicate annotation argument",
                ));
            }
            let value = match (&expression.kind, descriptor.as_str()) {
                (ExprKind::Int(value), "I") => {
                    DeclarationAnnotationValue::Int(i32::try_from(*value).map_err(|_| {
                        Diagnostic::new(
                            expression.offset,
                            "Annotation integer argument is out of range",
                        )
                    })?)
                }
                (ExprKind::Unary(operator, value), "I") if operator == "-" => match value.kind {
                    ExprKind::Int(value) => {
                        DeclarationAnnotationValue::Int(i32::try_from(-value).map_err(|_| {
                            Diagnostic::new(
                                expression.offset,
                                "Annotation integer argument is out of range",
                            )
                        })?)
                    }
                    _ => {
                        return Err(Diagnostic::new(
                            expression.offset,
                            "Unsupported annotation constant expression",
                        ));
                    }
                },
                (ExprKind::Boolean(value), "Z") => DeclarationAnnotationValue::Boolean(*value),
                (ExprKind::String(value), "Ljava/lang/String;") => {
                    DeclarationAnnotationValue::String(String::from_utf16(value).map_err(|_| {
                        Diagnostic::new(
                            expression.offset,
                            "Unsupported unpaired UTF-16 annotation string",
                        )
                    })?)
                }
                (_, "I" | "Z" | "Ljava/lang/String;") => {
                    return Err(Diagnostic::new(
                        expression.offset,
                        format!("Annotation argument type mismatch for {name}"),
                    ));
                }
                _ => {
                    return Err(Diagnostic::new(
                        expression.offset,
                        "Unsupported annotation array, class, enum, or numeric argument type",
                    ));
                }
            };
            values.push((name.to_owned(), value));
        }
        if let Some((name, _, _)) = definition
            .parameters
            .iter()
            .find(|(name, _, default)| !default && !supplied.contains(name))
        {
            return Err(Diagnostic::new(
                annotation.offset,
                format!("Missing required annotation argument: {name}"),
            ));
        }
        if definition.retention != AnnotationRetention::Source {
            result.push(DeclarationAnnotation {
                descriptor: format!("L{owner};"),
                runtime: definition.retention == AnnotationRetention::Runtime,
                values,
            });
        }
    }
    Ok(result)
}
