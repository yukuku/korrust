public class RegressionCheck { public static void main(String[] args) throws Exception {
if (!fixtures.AnnotatedForeign.class.isAnnotationPresent(Deprecated.class)) throw new AssertionError("class annotation absent");
if (Java_annotated_classKt.f(new fixtures.AnnotatedForeign()) != 1) throw new AssertionError("annotated class result");
final int[] calls = {0};
fixtures.AnnotatedForeign observed = new fixtures.AnnotatedForeign() { @Override public int value() { return ++calls[0] * 17 - 23; } };
if (Java_annotated_classKt.f(observed) != -6 || calls[0] != 1) throw new AssertionError("first virtual call/effect");
if (Java_annotated_classKt.f(observed) != 11 || calls[0] != 2) throw new AssertionError("second virtual call/effect");
final IllegalStateException expected = new IllegalStateException("callee marker");
try { Java_annotated_classKt.f(new fixtures.AnnotatedForeign() { @Override public int value() { calls[0]++; throw expected; } }); throw new AssertionError("callee exception missing"); } catch (IllegalStateException actual) { if (actual != expected || calls[0] != 3) throw new AssertionError("callee exception/effect"); }
try { Java_annotated_classKt.f(null); throw new AssertionError("null receiver accepted"); } catch (NullPointerException actual) { if (calls[0] != 3) throw new AssertionError("null call executed callee"); }
System.out.println("ok"); } }
