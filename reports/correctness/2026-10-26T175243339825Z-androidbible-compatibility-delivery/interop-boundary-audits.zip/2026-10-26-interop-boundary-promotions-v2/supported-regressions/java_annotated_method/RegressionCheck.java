public class RegressionCheck { public static void main(String[] args) throws Exception {
if (!fixtures.ForeignMethods.class.getMethod("annotated").isAnnotationPresent(Deprecated.class)) throw new AssertionError("method annotation absent");
if (Java_annotated_methodKt.f(new fixtures.ForeignMethods()) != 1) throw new AssertionError("annotated method result");
final int[] calls = {0};
fixtures.ForeignMethods observed = new fixtures.ForeignMethods() { @Override public int annotated() { return ++calls[0] * 17 - 23; } };
if (Java_annotated_methodKt.f(observed) != -6 || calls[0] != 1) throw new AssertionError("first virtual call/effect");
if (Java_annotated_methodKt.f(observed) != 11 || calls[0] != 2) throw new AssertionError("second virtual call/effect");
final IllegalStateException expected = new IllegalStateException("callee marker");
try { Java_annotated_methodKt.f(new fixtures.ForeignMethods() { @Override public int annotated() { calls[0]++; throw expected; } }); throw new AssertionError("callee exception missing"); } catch (IllegalStateException actual) { if (actual != expected || calls[0] != 3) throw new AssertionError("callee exception/effect"); }
try { Java_annotated_methodKt.f(null); throw new AssertionError("null receiver accepted"); } catch (NullPointerException actual) { if (calls[0] != 3) throw new AssertionError("null call executed callee"); }
System.out.println("ok"); } }
