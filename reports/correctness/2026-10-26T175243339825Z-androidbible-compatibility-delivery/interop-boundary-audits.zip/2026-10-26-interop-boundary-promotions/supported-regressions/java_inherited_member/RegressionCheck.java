public class RegressionCheck { public static void main(String[] args) throws Exception {
if (fixtures.ForeignMethods.class.getMethod("hashCode").getDeclaringClass() != Object.class) throw new AssertionError("fixture does not inherit Object.hashCode");
fixtures.ForeignMethods identity = new fixtures.ForeignMethods();
if (Java_inherited_memberKt.f(identity) != System.identityHashCode(identity)) throw new AssertionError("inherited identity hash");
final int[] calls = {0};
fixtures.ForeignMethods observed = new fixtures.ForeignMethods() { @Override public int hashCode() { return ++calls[0] * 17 - 23; } };
if (Java_inherited_memberKt.f(observed) != -6 || calls[0] != 1) throw new AssertionError("first virtual call/effect");
if (Java_inherited_memberKt.f(observed) != 11 || calls[0] != 2) throw new AssertionError("second virtual call/effect");
final IllegalStateException expected = new IllegalStateException("callee marker");
try { Java_inherited_memberKt.f(new fixtures.ForeignMethods() { @Override public int hashCode() { calls[0]++; throw expected; } }); throw new AssertionError("callee exception missing"); } catch (IllegalStateException actual) { if (actual != expected || calls[0] != 3) throw new AssertionError("callee exception/effect"); }
try { Java_inherited_memberKt.f(null); throw new AssertionError("null receiver accepted"); } catch (NullPointerException actual) { if (calls[0] != 3) throw new AssertionError("null call executed callee"); }
System.out.println("ok"); } }
